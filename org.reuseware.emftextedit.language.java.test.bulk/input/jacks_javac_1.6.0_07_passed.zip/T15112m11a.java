
package p1;
public class T15112m11a {
    protected static int i;
}
    