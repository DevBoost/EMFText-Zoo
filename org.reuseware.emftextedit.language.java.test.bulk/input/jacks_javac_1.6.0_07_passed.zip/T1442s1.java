
class T1442s1 {
    
        Object i;
        void foo() {
            i = new Object();
            int i;
            i = 1;
        }
    
}
