
package pkg;
public class Array20 {
    public static A[] array;
    protected static class A {}
}
    