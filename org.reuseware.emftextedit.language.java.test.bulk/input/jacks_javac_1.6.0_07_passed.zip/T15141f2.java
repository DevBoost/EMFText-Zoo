
public class T15141f2 {
    T15141f2 (){}
    public static void main(String[] args) {
        
	final int i;
	if (false)
	    i++;
    
    }
}
