
package p1;
public class T15112r2a {
    public T15112r2a(int i) { b = i; }
    protected static int a = 1;
    protected int b;
}
    