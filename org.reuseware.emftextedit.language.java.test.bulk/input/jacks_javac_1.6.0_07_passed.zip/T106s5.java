
public class T106s5 {
    T106s5 (){}
    public static void main(String[] args) {
        
        int[] ia = { 1, };
    
    }
}
