
public class T1510it7 {
    T1510it7 (){}
    public static void main(String[] args) {
        
        Object[] oa = new Object[] { new Object() };
    
    }
}
