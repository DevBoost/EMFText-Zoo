
public class T1414l2 {
    T1414l2 (){}
    public static void main(String[] args) {
        
        a: b: for (int i=0; i<10; ++i)
            break a;
    
    }
}
