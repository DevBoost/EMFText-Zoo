
public class T1414l7 {
    T1414l7 (){}
    public static void main(String[] args) {
        
        int i=0;
        a: do break a;
        while (++i<10);
    
    }
}
