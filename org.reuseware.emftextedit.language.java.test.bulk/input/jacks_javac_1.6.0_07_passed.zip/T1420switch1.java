
public class T1420switch1 {
    T1420switch1 (){}
    public static void main(String[] args) {
        
        switch (args.length) {
            case 0:
            int i;
        }
        int j;
    
    }
}
