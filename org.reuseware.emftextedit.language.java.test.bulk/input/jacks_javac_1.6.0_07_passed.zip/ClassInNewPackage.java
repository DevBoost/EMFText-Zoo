
package some_package_that_is_not_known_at_compile_time;

public class ClassInNewPackage {}
