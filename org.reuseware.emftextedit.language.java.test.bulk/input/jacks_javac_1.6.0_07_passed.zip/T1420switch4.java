
public class T1420switch4 {
    T1420switch4 (){}
    public static void main(String[] args) {
        
        switch (args.length) {
            case 0: return;
            case 1:
        }
        int i;
    
    }
}
