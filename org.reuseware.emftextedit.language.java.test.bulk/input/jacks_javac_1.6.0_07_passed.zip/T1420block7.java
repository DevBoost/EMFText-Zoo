
public class T1420block7 {
    T1420block7 (){}
    public static void main(String[] args) {
        
        int i;
        int j;
    
    }
}
