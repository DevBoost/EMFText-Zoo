
class T15141t7 {
    double d = 1, d2 = d++;
}
