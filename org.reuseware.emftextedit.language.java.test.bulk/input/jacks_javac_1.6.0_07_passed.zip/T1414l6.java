
public class T1414l6 {
    T1414l6 (){}
    public static void main(String[] args) {
        
        int i=0;
        a: while (++i<10)
            break a;
    
    }
}
