
class T1419e5 {
    
	void m() {
	    try {
		throw new Exception();
	    } catch (Exception e) {
	    }
	}
    
}
