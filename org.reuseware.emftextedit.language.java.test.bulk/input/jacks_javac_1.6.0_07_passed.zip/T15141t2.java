
class T15141t2 {
    short s = 1, s2 = s++;
}
