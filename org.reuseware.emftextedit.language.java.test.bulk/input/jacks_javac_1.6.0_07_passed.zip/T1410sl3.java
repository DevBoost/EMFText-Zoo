
class T1410sl3 {
    T1410sl3 (){}
    void foo(int i) {
        switch (i) {
            case 0: case (2-1): case (3-1): default:
        }
    }
}
