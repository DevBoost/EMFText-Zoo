
public class T149ee4 {
    T149ee4 (){}
    public static void main(String[] args) {
        
        if ((byte) 0 == (byte) 1)
            ;
    
    }
}
