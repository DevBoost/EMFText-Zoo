
package p1;
public class T151222a18a {
    protected void m(Object o, String s) {}
}
    