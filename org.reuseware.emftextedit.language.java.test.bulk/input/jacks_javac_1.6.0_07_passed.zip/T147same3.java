
public class T147same3 {
    T147same3 (){}
    public static void main(String[] args) {
        
        int i;
        Cloneable: i = 1;
        new Cloneable() {};
    
    }
}
