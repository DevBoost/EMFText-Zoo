
public class T149ee9 {
    T149ee9 (){}
    public static void main(String[] args) {
        
        final char aconst = 0;
        char anonconst = 1;

        if (anonconst == aconst)
            ;
    
    }
}
