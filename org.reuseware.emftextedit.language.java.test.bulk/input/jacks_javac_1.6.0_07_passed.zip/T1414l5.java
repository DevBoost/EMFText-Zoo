
public class T1414l5 {
    T1414l5 (){}
    public static void main(String[] args) {
        
        a: for (int i=0; i<10; ++i)
            break a;
    
    }
}
