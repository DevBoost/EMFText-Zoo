
class t1417c1 {
    

        void m() {

            throw new RuntimeException(); // unchecked

        }

    
}
