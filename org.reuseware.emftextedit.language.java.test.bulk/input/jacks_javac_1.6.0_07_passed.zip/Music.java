
package org.rpgpoet;
import java.util.Random;
public interface Music { Random[] wizards = new Random[4]; }
