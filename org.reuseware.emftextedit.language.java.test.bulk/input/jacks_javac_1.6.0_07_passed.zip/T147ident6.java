
public class T147ident6 {
    T147ident6 (){}
    public static void main(String[] args) {
        
        int i;
        \u0061\u003a break a;
        b: break \u0062;
    
    }
}
