
public class T147enclosed5 {
    T147enclosed5 (){}
    public static void main(String[] args) {
        
        test: ;
    
    }
}
