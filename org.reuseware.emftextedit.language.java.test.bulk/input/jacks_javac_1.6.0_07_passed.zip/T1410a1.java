
class T1410a1 {
    T1410a1 (){}
    void foo(int i) {
        switch (i) {
            case 0:
        }
    }
}
