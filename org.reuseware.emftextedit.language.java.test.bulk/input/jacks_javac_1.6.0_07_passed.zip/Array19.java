
package pkg;
public class Array19 {
    public static A[] array;
    public static class A {}
}
    