
class T15152a10 {
    int i = 1, j = --(i);
}
