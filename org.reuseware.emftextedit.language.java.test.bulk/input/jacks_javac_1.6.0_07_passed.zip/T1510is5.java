
public class T1510is5 {
    T1510is5 (){}
    public static void main(String[] args) {
        
        int[] ia = new int[] { 1, };
    
    }
}
