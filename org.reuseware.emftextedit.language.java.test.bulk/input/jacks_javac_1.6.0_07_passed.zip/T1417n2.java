
class T1417n2 {
    

        void m() throws Throwable {

            throw null;

        }

    
}
