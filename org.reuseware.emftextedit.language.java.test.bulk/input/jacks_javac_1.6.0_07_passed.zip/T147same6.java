
class T147same6 {
    
        void foo(String[] args) {
            int i;
            args: i = 1;
            i = args.length;
        }
    
}
