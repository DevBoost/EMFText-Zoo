
public class T15151f2 {
    T15151f2 (){}
    public static void main(String[] args) {
        
	final int i;
	if (false)
	    ++i;
    
    }
}
