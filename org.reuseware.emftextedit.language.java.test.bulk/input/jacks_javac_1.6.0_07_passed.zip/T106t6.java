
public class T106t6 {
    T106t6 (){}
    public static void main(String[] args) {
        
        Object[] oa = { 1 };
    
    }
}
