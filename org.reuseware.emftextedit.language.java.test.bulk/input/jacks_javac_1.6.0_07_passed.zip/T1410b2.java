
class T1410b2 {
    public static void main(String[] args) {
	System.out.print("OK");
	switch (args.length) {
        case 1:
	    int i = 1;
	    break;
	}
    }
}
    