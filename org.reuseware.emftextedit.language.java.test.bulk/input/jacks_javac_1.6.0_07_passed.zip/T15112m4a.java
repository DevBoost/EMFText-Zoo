
package p1;
public class T15112m4a {
    protected static int i;
}
    