
public class T149ee7 {
    T149ee7 (){}
    public static void main(String[] args) {
        
        final short aconst = 0;
        short anonconst = 1;

        if (anonconst == aconst)
            ;
    
    }
}
