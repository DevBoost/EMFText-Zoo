
class T15142t5 {
    long l = 1, l2 = l--;
}
