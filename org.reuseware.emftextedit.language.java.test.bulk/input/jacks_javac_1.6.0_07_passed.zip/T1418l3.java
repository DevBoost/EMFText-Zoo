
class T1418l3 {
    
        static synchronized void foo() {
            synchronized (T1418l3.class) {}
        }
    
}
