
public abstract class EmptyAbstractMethodBody {
    public abstract void foo();
}
