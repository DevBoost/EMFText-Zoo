
public class T1415l7 {
    T1415l7 (){}
    public static void main(String[] args) {
        
        int i=0;
        a: do continue a;
        while (++i<10);
    
    }
}
