
class T15151t6 {
    float f = 1, f2 = ++f;
}
