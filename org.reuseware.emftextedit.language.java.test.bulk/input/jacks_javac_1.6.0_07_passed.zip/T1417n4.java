
class T1417n4 {
    

        void m() throws Throwable {

            new Object() {{ if (true) throw null; }};

        }

    
}
