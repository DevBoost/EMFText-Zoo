
class T15142a10 {
    int i = 1, j = (i)--;
}
