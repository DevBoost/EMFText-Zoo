
public class T1418e1 {
    T1418e1 (){}
    public static void main(String[] args) {
        
        synchronized ("") {}
    
    }
}
