
public class T1420for1 {
    T1420for1 (){}
    public static void main(String[] args) {
        
        boolean b = true;
        for ( ; b; );
        int i;
    
    }
}
