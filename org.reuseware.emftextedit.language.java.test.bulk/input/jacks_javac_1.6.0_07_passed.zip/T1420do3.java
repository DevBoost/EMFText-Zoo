
public class T1420do3 {
    T1420do3 (){}
    public static void main(String[] args) {
        
        boolean b = true;
        a: do continue a; while (b);
        int i;
    
    }
}
