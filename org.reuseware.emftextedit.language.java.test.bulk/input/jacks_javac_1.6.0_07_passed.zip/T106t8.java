
public class T106t8 {
    T106t8 (){}
    public static void main(String[] args) {
        
        Object[] oa = { null };
    
    }
}
