
class T1410vt4 {
    T1410vt4 (){}
    void foo(int i) {
        switch (i) {
        }
    }
}
