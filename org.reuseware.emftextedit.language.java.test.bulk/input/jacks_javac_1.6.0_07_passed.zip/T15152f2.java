
public class T15152f2 {
    T15152f2 (){}
    public static void main(String[] args) {
        
	final int i;
	if (false)
	    --i;
    
    }
}
