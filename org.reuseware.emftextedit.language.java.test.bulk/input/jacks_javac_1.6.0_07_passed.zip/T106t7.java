
public class T106t7 {
    T106t7 (){}
    public static void main(String[] args) {
        
        Object[] oa = { new Object() };
    
    }
}
