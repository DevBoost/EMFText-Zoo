
class T151221ac2 {
    public T151221ac2(String x, String y) {}
    private T151221ac2(String x, char[] y) {}
}
class T151221ac2_Test {
    Object o = new T151221ac2("hi", null);
}
    