
abstract class T151222a5a {
    public abstract void m();
}
interface T151222a5b {
    void m();
}
abstract class T151222a5c extends T151222a5a implements T151222a5b {
    { m(); }
}
    