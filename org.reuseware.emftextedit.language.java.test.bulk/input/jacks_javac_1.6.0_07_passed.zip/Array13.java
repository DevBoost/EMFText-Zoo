
package pkg;
public class Array13 {
    public static A[] array;
    static class A {}
}
    