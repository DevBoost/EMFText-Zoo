
public class T1420block2 {
    T1420block2 (){}
    public static void main(String[] args) {
        
        { int i; }
        int j;
    
    }
}
