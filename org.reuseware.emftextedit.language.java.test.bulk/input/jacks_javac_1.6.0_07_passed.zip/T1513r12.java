
public class T1513r12 {
    T1513r12 (){}
    public static void main(String[] args) {
        
	(new int[1])[0]++;
    
    }
}
