
class T15121t10 {
    
	class A {
	    void m() {}
	}
	class B extends A {
	    { super.m(); }
	}
    
}
