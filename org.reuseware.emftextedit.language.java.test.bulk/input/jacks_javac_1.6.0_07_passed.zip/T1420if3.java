
public class T1420if3 {
    T1420if3 (){}
    public static void main(String[] args) {
        
        if (true)
            return;
        else
            ;
        int i;
    
    }
}
