
public class T1442vs4 {
    T1442vs4 (){}
    public static void main(String[] args) {
        
        { int i; }
        int i;
    
    }
}
