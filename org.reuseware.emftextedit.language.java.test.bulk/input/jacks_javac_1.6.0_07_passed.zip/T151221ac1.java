
class T151221ac1 {
    public T151221ac1(String s) {}
    private T151221ac1(Integer i) {}
}
class T151221ac1_Test {
    Object o = new T151221ac1(null);
}
    