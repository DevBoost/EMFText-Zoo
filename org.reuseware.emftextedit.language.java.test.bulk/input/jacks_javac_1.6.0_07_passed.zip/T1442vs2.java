
public class T1442vs2 {
    T1442vs2 (){}
    public static void main(String[] args) {
        
        int i = 1, j = i;
    
    }
}
