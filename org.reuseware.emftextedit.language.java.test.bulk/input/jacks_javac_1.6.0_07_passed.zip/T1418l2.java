
class T1418l2 {
    
        synchronized void foo() {
            synchronized (this) {}
        }
    
}
