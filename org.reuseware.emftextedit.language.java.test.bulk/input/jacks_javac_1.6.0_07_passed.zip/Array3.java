
package pkg;
public class Array3 {
    protected static class A {}
}
    