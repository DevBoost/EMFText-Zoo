
public class T149ee12 {
    T149ee12 (){}
    public static void main(String[] args) {
        
        if (0L == 1L)
            ;
    
    }
}
