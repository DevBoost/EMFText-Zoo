
public class T1414l1 {
    T1414l1 (){}
    public static void main(String[] args) {
        
        a: {
            for (int i=0; i<10; ++i)
                break a;
        }
    
    }
}
