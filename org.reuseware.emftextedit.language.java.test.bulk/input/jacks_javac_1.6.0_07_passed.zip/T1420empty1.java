
public class T1420empty1 {
    T1420empty1 (){}
    public static void main(String[] args) {
        
        ;
        int i;
    
    }
}
