
class T15141a10 {
    int i = 1, j = (i)++;
}
