
package p1;
class T15112m5a {
    protected int i;
}
interface T15112m5b {
    int i = 1;
}
public class T15112m5c extends T15112m5a implements T15112m5b {}
    