
public class T1420switch6 {
    T1420switch6 (){}
    public static void main(String[] args) {
        
        switch (args.length) {
            default: return;
            case 0: break;
        }
        int i;
    
    }
}
