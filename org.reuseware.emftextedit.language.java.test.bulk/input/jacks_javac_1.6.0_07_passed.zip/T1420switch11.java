
class T1420switch11 {
    T1420switch11 (){}
    void foo(int i) {
        switch (i) {
            
        case 0: return;
        case 1: boolean b;
    
        }
    }
}
