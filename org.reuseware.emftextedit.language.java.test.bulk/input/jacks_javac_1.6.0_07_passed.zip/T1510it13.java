
public class T1510it13 {
    T1510it13 (){}
    public static void main(String[] args) {
        
        int[][] iaa = new int[][] { {1, 2}, null };
    
    }
}
