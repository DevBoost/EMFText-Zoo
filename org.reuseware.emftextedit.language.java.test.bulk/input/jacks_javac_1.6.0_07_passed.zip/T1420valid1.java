
public class T1420valid1 {
    T1420valid1 (){}
    public static void main(String[] args) {
        
        int n = 5, k;
        while (n > 7) k = 2;
    
    }
}
