
package p1;
public class T15111a4a {
    protected int i = 1;
}
