
class T147same5 {
    
        int test;
        void foo() {
            int i;
            test: i = 1;
            test = 1;
        }
    
}
