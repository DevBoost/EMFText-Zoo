
public class T1414p4 {
    T1414p4 (){}
    public static void main(String[] args) {
        
        int i=0;
        do break;
        while (++i<10);
    
    }
}
