
public class T1420label1 {
    T1420label1 (){}
    public static void main(String[] args) {
        
        int i;
        a: i = 1;
        int j;
    
    }
}
