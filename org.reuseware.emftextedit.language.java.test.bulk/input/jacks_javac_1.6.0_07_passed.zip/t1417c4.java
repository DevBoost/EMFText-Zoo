
class t1417c4 {
    

        void m() throws Throwable {

            throw new Exception(); // checked and declared

        }

    
}
