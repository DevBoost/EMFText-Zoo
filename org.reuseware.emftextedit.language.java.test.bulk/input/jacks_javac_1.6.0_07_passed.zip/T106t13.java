
public class T106t13 {
    T106t13 (){}
    public static void main(String[] args) {
        
        int[][] iaa = { {1, 2}, null };
    
    }
}
