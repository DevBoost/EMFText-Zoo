
public class T149ee10 {
    T149ee10 (){}
    public static void main(String[] args) {
        
        if (0 == 1)
            ;
    
    }
}
