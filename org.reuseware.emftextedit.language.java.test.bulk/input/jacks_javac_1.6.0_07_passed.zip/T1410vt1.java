
class T1410vt1 {
    T1410vt1 (){}
    void foo(char i) {
        switch (i) {
        }
    }
}
