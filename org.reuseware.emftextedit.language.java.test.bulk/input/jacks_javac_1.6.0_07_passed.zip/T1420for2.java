
public class T1420for2 {
    T1420for2 (){}
    public static void main(String[] args) {
        
        for ( ; ; ) break;
        int i;
    
    }
}
