
public class T1420switch5 {
    T1420switch5 (){}
    public static void main(String[] args) {
        
        switch (args.length) {
            case 0: return;
        }
        int i;
    
    }
}
