
package pkg;
public class Array10 {
    public static A[] array;
    public static class A {}
}
    