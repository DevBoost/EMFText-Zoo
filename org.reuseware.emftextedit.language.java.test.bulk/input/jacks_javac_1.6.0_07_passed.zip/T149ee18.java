
public class T149ee18 {
    T149ee18 (){}
    public static void main(String[] args) {
        
        if ("hi" == "there")
            ;
    
    }
}
