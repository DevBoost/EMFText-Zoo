
public class T1510it10 {
    T1510it10 (){}
    public static void main(String[] args) {
        
        int[][] iaa = new int[][] { {1} };
    
    }
}
