
class T1410a10 {
    T1410a10 (){}
    void foo(char i) {
        switch (i) {
            case (short) 1:
        }
    }
}
