
public class T1415l6 {
    T1415l6 (){}
    public static void main(String[] args) {
        
        int i=0;
        a: while (++i<10)
            continue a;
    
    }
}
