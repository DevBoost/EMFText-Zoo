
class T1410a9 {
    T1410a9 (){}
    void foo(byte i) {
        switch (i) {
            case '1':
        }
    }
}
