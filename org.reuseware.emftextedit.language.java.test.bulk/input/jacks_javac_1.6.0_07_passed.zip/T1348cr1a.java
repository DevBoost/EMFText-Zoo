
class T1348cr1a {
    final int i = 3;
    final String s = "c";
    static final int i1 = 4;
    static final String s1 = "d";
}
