
public class T147same2 {
    T147same2 (){}
    public static void main(String[] args) {
        
        int i;
        T147same2: i = 1;
        new T147same2();
    
    }
}
