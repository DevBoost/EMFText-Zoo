
public class T1510is3 {
    T1510is3 (){}
    public static void main(String[] args) {
        
        int[] ia = new int[] { 1, 2 };
    
    }
}
