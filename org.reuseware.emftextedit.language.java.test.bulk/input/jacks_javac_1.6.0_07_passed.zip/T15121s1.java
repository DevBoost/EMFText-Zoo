
class T15121s1 {
    
        int T15121s1; // obscure the class name from normal expressions
        String s = T15121s1.super.toString();
    
}
