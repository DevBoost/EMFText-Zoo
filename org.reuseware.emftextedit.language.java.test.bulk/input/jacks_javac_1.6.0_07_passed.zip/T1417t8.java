
public class T1417t8 {
    T1417t8 (){}
    public static void main(String[] args) {
        

        try {

            throw null;

        } catch (Throwable t) {

        }

    
    }
}
