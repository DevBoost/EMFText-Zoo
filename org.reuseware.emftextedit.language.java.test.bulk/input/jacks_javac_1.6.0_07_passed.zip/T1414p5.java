
public class T1414p5 {
    T1414p5 (){}
    public static void main(String[] args) {
        
        for (int i=0; i<10; ++i) {
            break;
        }
    
    }
}
