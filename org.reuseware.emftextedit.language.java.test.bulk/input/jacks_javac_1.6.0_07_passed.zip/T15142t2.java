
class T15142t2 {
    short s = 1, s2 = s--;
}
