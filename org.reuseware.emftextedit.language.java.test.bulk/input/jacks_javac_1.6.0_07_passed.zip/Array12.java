
package pkg;
public class Array12 {
    public static A[] array;
    protected static class A {}
}
    