
public class EmptyBlockMethodBody {
    public void foo() {}
}
