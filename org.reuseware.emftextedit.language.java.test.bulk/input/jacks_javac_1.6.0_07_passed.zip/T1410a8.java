
class T1410a8 {
    T1410a8 (){}
    void foo(byte i) {
        switch (i) {
            case (short) 1:
        }
    }
}
