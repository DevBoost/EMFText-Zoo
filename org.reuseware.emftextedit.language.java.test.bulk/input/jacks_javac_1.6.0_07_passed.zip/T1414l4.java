
public class T1414l4 {
    T1414l4 (){}
    public static void main(String[] args) {
        
        a: break a;
    
    }
}
