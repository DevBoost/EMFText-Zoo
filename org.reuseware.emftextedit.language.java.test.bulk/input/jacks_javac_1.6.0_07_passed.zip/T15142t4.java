
class T15142t4 {
    int i = 1, i2 = i--;
}
