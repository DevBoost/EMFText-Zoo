
public class T1442vs7 {
    T1442vs7 (){}
    public static void main(String[] args) {
        
        for (int i; ; i = 1);
    
    }
}
