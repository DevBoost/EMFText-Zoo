
class T15151a10 {
    int i = 1, j = ++(i);
}
