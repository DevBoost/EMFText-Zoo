
package pkg;
public class Array21 {
    public static A[] array;
    protected static class A {}
}
    