
public class T106t10 {
    T106t10 (){}
    public static void main(String[] args) {
        
        int[][] iaa = { {1} };
    
    }
}
