
public class T1420try1 {
    T1420try1 (){}
    public static void main(String[] args) {
        
        try {
            new Object();
        } catch (RuntimeException e) {
            return;
        }
        int i;
    
    }
}
