
class A {
    void foo(String s) {}
}
abstract class T151222a3 extends A {
    void foo(Object o) {}
    {
	foo("");
    }
}
    