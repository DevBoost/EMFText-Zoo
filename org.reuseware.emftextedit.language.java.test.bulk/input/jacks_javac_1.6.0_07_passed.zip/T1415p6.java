
public class T1415p6 {
    T1415p6 (){}
    public static void main(String[] args) {
        
        int i=0;
        while (++i<10) {
            continue;
        }
    
    }
}
