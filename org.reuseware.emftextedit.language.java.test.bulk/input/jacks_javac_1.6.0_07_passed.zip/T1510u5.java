
public class T1510u5 {
    T1510u5 (){}
    public static void main(String[] args) {
        
	Object o = new int[-1];
    
    }
}
