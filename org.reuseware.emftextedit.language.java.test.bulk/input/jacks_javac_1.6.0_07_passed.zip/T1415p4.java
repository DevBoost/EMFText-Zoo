
public class T1415p4 {
    T1415p4 (){}
    public static void main(String[] args) {
        
        int i=0;
        do continue;
        while (++i<10);
    
    }
}
