
class T1419e6 {
    
	void m() {
	    try {
		throw new Exception();
	    } catch (Exception e) {
	    } finally {
	    }
	}
    
}
