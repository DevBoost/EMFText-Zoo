
package pkg;
public class Array32 {
    public static A[] array;
    private static class A {}
}
    