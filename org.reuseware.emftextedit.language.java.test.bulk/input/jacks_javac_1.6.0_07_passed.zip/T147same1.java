
package test;
class T147same1 {
    void foo() {
        int i;
        test: i = 1;
        new test.T147same1();
    }
}
    