
class T15152t3 {
    char c = 1, c2 = --c;
}
