
public class T149ee17 {
    T149ee17 (){}
    public static void main(String[] args) {
        
        final double aconst = 0D;
        double anonconst = 1D;

        if (anonconst == aconst)
            ;
    
    }
}
