
public class T1442vs3 {
    T1442vs3 (){}
    public static void main(String[] args) {
        
        int i;
        i = 1;
    
    }
}
