
package pkg;
public class Array29 {
    public static A[] array;
    protected static class A {}
}
    