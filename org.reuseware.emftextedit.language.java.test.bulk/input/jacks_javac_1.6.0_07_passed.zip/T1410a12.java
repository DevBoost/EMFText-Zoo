
class T1410a12 {
    T1410a12 (){}
    void foo(char i) {
        switch (i) {
            case (byte) 1:
        }
    }
}
