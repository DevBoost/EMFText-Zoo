
package Vector;
public class Mosquito {}
