
class T1410a6 {
    T1410a6 (){}
    void foo(byte i) {
        switch (i) {
            case 127:
        }
    }
}
