
public class T1420do2 {
    T1420do2 (){}
    public static void main(String[] args) {
        
        boolean b = true;
        do continue; while (b);
        int i;
    
    }
}
