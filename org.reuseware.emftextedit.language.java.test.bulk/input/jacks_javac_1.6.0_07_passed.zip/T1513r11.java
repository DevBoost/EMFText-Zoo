
class T1513r11 {
    
	int[] m() { return null; }
	void n() {
	    m()[0]++;
	}
    
}
