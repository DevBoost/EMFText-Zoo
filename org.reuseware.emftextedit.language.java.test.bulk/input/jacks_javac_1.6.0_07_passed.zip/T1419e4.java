
class T1419e4 {
    
	void m() throws Exception {
	    try {
		throw new Exception();
	    } finally {
	    }
	}
    
}
