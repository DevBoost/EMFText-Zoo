
public class T1513f1 {
    T1513f1 (){}
    public static void main(String[] args) {
        
	final int[] i = {0};
	i[0]++;
    
    }
}
