
public class T1420catch9 {
    T1420catch9 (){}
    public static void main(String[] args) {
        
        int i, j=0;
        try {
            i = 1/j;
        } catch (ArithmeticException ae) {
        }
    
    }
}
