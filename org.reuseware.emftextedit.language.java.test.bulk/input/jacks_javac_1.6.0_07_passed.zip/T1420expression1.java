
public class T1420expression1 {
    T1420expression1 (){}
    public static void main(String[] args) {
        
        System.out.println();
        int i;
        i = 1;
        i++;
        --i;
        new Object();
        new Object() {};
    
    }
}
