
class T1410a11 {
    T1410a11 (){}
    void foo(short i) {
        switch (i) {
            case '1':
        }
    }
}
