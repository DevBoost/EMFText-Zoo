
package p1;
public class T15112m3a {
    protected int i;
}
    