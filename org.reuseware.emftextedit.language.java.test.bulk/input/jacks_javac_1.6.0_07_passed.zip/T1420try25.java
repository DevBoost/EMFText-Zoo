
public class T1420try25 {
    T1420try25 (){}
    public static void main(String[] args) {
        
        try {
            new Object();
        } finally {
        }
        int i;
    
    }
}
