
class T1442s3 {
    
        static Object i;
        static void foo() {
            i = new Object();
            int i;
            i = 1;
        }
    
}
