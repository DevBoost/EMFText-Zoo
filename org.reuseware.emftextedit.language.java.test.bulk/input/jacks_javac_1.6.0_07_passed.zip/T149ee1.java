
public class T149ee1 {
    T149ee1 (){}
    public static void main(String[] args) {
        
        if (true)
            ;
    
    }
}
