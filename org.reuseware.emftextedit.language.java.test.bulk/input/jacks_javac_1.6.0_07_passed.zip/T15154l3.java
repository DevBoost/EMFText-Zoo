
class T15154l3 {
    T15154l3 (){}
    void foo(int i) {
        switch (i) {
            case 0:
            case ((-0x8000000000000000L == 0x8000000000000000L) ? 1 : 0):
        }
    }
}
