
class T15151t1 {
    byte b = 1, b2 = ++b;
}
