
class T1442s2 {
    
        static Object i;
        void foo() {
            i = new Object();
            int i;
            i = 1;
        }
    
}
