
public class T149ee2 {
    T149ee2 (){}
    public static void main(String[] args) {
        
        if (false == true)
            ;
    
    }
}
