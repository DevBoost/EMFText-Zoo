
package p1;
public class T151222a7a {
    void m(Object o, String s) {}
}
    