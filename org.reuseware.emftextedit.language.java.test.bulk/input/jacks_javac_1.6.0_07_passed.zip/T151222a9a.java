
package p1;
public class T151222a9a {
    protected void m(Object o, String s) {}
}
    