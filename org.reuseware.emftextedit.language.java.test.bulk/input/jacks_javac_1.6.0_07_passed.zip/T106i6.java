
public class T106i6 {
    T106i6 (){}
    public static void main(String[] args) {
        
        int[][] iaa = { {1}, {2} };
    
    }
}
