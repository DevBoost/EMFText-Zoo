
class T1410e1 {
    void foo() {
        int i;
        switch (i = 1) {
            case 1:
        }
    }
}
    