
public class T1420try7 {
    T1420try7 (){}
    public static void main(String[] args) {
        
        try {
            new Object();
        } catch (RuntimeException e) {
            return;
        } finally {
        }
        int i;
    
    }
}
