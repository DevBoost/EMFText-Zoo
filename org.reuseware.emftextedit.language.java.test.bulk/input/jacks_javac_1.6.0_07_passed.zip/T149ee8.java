
public class T149ee8 {
    T149ee8 (){}
    public static void main(String[] args) {
        
        if ((char) 0 == (char) 1)
            ;
    
    }
}
