
package T76name2pkg;
public interface pinterface {}
    