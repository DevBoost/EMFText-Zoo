
public class T149ee11 {
    T149ee11 (){}
    public static void main(String[] args) {
        
        final int aconst = 0;
        int anonconst = 1;

        if (anonconst == aconst)
            ;
    
    }
}
