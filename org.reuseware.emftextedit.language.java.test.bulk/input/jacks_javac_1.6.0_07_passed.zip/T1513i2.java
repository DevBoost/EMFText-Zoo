
public class T1513i2 {
    T1513i2 (){}
    public static void main(String[] args) {
        
	final int[] i = {};
	i[0] = 0;
    
    }
}
