
package p1;
public class T15111a3a {
    protected int i = 1;
}
