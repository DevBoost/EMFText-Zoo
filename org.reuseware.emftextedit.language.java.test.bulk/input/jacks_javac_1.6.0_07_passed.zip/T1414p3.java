
public class T1414p3 {
    T1414p3 (){}
    public static void main(String[] args) {
        
        int i=0;
        while (++i<10)
            break;
    
    }
}
