
public class T1420do4 {
    T1420do4 (){}
    public static void main(String[] args) {
        
        do break; while (true);
        int i;
    
    }
}
