
public class T1442s4 {
    T1442s4 (){}
    public static void main(String[] args) {
        
        Object i;
        new Object() {
            int i;
        };
    
    }
}
