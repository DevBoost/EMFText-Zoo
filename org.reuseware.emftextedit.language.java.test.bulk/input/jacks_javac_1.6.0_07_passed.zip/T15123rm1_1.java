
package p1;
public class T15123rm1_1 {
    protected void foo() { // this is overridden in T15123rm1_3
        System.out.print("1");
    }
}
    