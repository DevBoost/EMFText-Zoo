
public interface I {
    int hashCode();
}
