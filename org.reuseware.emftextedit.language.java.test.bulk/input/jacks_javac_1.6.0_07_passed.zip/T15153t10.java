
class T15153t10 {
    T15153t10 (){}
    void foo() {
        short n1 = +1;
    }
}
