
public class AbstractInnerInterface {
    abstract interface Inter {}
}
