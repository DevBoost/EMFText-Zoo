
class T15153t9 {
    T15153t9 (){}
    void foo() {
        double n1 = +1d;
    }
}
