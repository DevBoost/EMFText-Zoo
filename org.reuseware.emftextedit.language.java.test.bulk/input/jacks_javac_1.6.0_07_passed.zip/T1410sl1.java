
class T1410sl1 {
    T1410sl1 (){}
    void foo(int i) {
        switch (i) {
            case 0: case 1:
        }
    }
}
