
class T15152t5 {
    long l = 1, l2 = --l;
}
