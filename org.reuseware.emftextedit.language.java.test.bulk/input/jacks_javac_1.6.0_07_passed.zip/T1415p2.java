
public class T1415p2 {
    T1415p2 (){}
    public static void main(String[] args) {
        
        for (int i=0; i<10; ++i)
            continue;
    
    }
}
