
package p1;
public class T151241rsuper1a {
    public String a() { return null; }
    protected String i() { return a(); }
    protected static String s() { return "2"; }
}
    