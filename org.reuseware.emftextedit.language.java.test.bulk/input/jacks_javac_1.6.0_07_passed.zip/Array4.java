
package pkg;
public class Array4 {
    protected static class A {}
}
    