
public class ExceptionalReturnInNonVoid {
    public boolean foo() { throw new RuntimeException("foo()"); }
}
