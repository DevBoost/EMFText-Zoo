
public class T1417t9 {
    T1417t9 (){}
    public static void main(String[] args) {
        

        try {

            throw new Throwable();

        } catch (Throwable t) {

        }

    
    }
}
