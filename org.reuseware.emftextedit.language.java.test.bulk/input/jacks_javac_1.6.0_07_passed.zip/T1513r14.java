
public class T1513r14 {
    T1513r14 (){}
    public static void main(String[] args) {
        
	int[][] i = { { 1 } };
	i[0][0]++;
	(i[0])[0]--;
    
    }
}
