
class T1410vt3 {
    T1410vt3 (){}
    void foo(short i) {
        switch (i) {
        }
    }
}
