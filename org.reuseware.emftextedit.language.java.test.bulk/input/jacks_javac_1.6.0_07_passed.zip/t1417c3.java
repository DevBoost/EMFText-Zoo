
class t1417c3 {
    

        void m() {

            try {

                throw new Exception(); // checked and caught

            } catch (Exception e) {

            }

        }

    
}
