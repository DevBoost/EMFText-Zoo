
public class T147same7 {
    T147same7 (){}
    public static void main(String[] args) {
        
        int test, i;
        test: i = 1;
        test = 1;
    
    }
}
