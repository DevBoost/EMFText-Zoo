
package p1;
class T15112m13a {
    protected int i;
}
interface T15112m13b {
    int i = 1;
}
public class T15112m13c extends T15112m13a implements T15112m13b {}
    