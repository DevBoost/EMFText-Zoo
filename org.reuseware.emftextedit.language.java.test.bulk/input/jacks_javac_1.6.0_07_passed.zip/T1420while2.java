
public class T1420while2 {
    T1420while2 (){}
    public static void main(String[] args) {
        
        while (true) break;
        int i;
    
    }
}
