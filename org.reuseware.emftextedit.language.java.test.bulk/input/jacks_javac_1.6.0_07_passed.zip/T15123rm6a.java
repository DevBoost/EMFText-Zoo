
package p1;
public class T15123rm6a {
    protected void m() {
	System.out.print(1);
    }
}
    