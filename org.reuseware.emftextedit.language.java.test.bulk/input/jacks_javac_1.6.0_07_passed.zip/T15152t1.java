
class T15152t1 {
    byte b = 1, b2 = --b;
}
