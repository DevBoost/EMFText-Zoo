
public class ArrayLengthIsInt {
    void foo() {
        int[] foo = new int[3];
        int val = foo.length;
    }
}
