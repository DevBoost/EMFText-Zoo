
public class T106s1 {
    T106s1 (){}
    public static void main(String[] args) {
        
        int[] ia = {};
    
    }
}
