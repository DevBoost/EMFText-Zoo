
public class T1510it6 {
    T1510it6 (){}
    public static void main(String[] args) {
        
        Object[] oa = new Object[] { 1 };
    
    }
}
