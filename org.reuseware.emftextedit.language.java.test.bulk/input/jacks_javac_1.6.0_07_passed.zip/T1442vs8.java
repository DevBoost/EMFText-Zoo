
public class T1442vs8 {
    T1442vs8 (){}
    public static void main(String[] args) {
        
        for (int i = 1; i < 1; );
        for (int i; ; );
    
    }
}
