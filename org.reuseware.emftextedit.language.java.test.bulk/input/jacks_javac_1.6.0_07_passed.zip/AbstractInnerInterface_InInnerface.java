
public interface AbstractInnerInterface_InInnerface {
    abstract interface Inter {}
}
