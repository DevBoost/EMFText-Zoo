
package pkg;
public class Array30 {
    public static A[] array;
    protected static class A {}
}
    