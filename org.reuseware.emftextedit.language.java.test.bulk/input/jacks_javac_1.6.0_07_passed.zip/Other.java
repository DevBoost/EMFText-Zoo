
package other;
public class Other { public static String hello = "Hello"; }
    