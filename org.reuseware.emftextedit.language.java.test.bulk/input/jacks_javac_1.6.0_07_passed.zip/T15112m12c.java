
package p1;
class T15112m12a {
    protected int i;
}
interface T15112m12b {
    int i = 1;
}
public class T15112m12c extends T15112m12a implements T15112m12b {}
    