
class T147same4 {
    
        void test() {}
        void foo() {
            int i;
            test: i = 1;
            test();
        }
    
}
