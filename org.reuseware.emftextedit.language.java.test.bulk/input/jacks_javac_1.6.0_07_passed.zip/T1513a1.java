
public class T1513a1 {
    T1513a1 (){}
    public static void main(String[] args) {
        
        int i = new int[]{1}[0];
    
    }
}
