
package pkg;
public class Array23 {
    public static A[] array;
    private static class A {}
}
    