
public class T1420label3 {
    T1420label3 (){}
    public static void main(String[] args) {
        
        a: while (true)
            break a;
        int i;
    
    }
}
