
class T15141t5 {
    long l = 1, l2 = l++;
}
