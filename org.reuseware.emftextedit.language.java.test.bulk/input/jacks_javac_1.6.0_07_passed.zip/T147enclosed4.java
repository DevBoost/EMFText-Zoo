
public class T147enclosed4 {
    T147enclosed4 (){}
    public static void main(String[] args) {
        
        test: {}
    
    }
}
