
public class T149ee16 {
    T149ee16 (){}
    public static void main(String[] args) {
        
        if (0D == 1D)
            ;
    
    }
}
