
package pkg;
public class Array31 {
    public static A[] array;
    static class A {}
}
    