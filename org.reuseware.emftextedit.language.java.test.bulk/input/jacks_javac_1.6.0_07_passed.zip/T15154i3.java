
class T15154i3 {
    T15154i3 (){}
    void foo(int i) {
        switch (i) {
            case 0:
            case ((-0x80000000 == 0x80000000) ? 1 : 0):
        }
    }
}
