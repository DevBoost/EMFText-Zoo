
class T15153t6 {
    T15153t6 (){}
    void foo() {
        int n1 = +1;
    }
}
