
package pkg;
public class Array1 {}
    