
class T15142t3 {
    char c = 1, c2 = c--;
}
