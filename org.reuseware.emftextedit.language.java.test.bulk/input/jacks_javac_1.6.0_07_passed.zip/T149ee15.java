
public class T149ee15 {
    T149ee15 (){}
    public static void main(String[] args) {
        
        final float aconst = 0F;
        float anonconst = 1F;

        if (anonconst == aconst)
            ;
    
    }
}
