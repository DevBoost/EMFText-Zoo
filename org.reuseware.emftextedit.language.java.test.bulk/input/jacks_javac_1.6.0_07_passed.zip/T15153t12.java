
class T15153t12 {
    T15153t12 (){}
    void foo() {
        byte n1 = +1;
    }
}
