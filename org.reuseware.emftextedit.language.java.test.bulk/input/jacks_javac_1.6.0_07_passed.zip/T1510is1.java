
public class T1510is1 {
    T1510is1 (){}
    public static void main(String[] args) {
        
        int[] ia = new int[] {};
    
    }
}
