
public class T1510it1 {
    T1510it1 (){}
    public static void main(String[] args) {
        
        short s = 1;
        int[] ia = new int[] { s, '1' };
    
    }
}
