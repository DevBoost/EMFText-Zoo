
class T15151t3 {
    char c = 1, c2 = ++c;
}
