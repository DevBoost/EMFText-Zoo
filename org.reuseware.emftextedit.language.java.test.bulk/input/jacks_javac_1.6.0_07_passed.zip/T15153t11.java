
class T15153t11 {
    T15153t11 (){}
    void foo() {
        char n1 = +'1';
    }
}
