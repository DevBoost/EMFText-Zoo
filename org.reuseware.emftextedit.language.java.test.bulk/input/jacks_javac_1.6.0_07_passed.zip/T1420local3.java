
public class T1420local3 {
    T1420local3 (){}
    public static void main(String[] args) {
        
        int i;
        int j;
    
    }
}
