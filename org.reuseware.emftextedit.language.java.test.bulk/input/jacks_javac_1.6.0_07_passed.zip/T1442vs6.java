
public class T1442vs6 {
    T1442vs6 (){}
    public static void main(String[] args) {
        
        for (int i = 1, j = i; ; );
    
    }
}
