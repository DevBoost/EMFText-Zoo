
public class T1415l8 {
    T1415l8 (){}
    public static void main(String[] args) {
        
        a: for (int i=0; i<10; ++i) {
            continue a;
        }
    
    }
}
