
class T15141t1 {
    byte b = 1, b2 = b++;
}
