
public class T1442vs5 {
    T1442vs5 (){}
    public static void main(String[] args) {
        
        for (int i = (i = 1) + i; ; );
    
    }
}
