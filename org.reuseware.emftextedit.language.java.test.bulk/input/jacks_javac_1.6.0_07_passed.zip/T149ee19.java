
public class T149ee19 {
    T149ee19 (){}
    public static void main(String[] args) {
        
        final String aconst = "hi";
        String anonconst = "there";

        if (anonconst == aconst)
            ;
    
    }
}
