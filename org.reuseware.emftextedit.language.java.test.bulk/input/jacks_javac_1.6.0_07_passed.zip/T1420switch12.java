
class T1420switch12 {
    T1420switch12 (){}
    void foo(int i) {
        switch (i) {
            
        case 0:
            boolean b1;
            boolean b2;
    
        }
    }
}
