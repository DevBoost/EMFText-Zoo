
class T1417n1 {
    

        void m() {

            throw null;

        }

    
}
