
public class T149ee3 {
    T149ee3 (){}
    public static void main(String[] args) {
        
        final boolean aconst = false;
        boolean anonconst = true;

        if (aconst == anonconst)
            ;
    
    }
}
