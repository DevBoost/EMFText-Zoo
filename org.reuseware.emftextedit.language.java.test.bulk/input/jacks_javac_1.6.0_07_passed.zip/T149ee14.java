
public class T149ee14 {
    T149ee14 (){}
    public static void main(String[] args) {
        
        if (0F == 1F)
            ;
    
    }
}
