
public class T143s7 {
    T143s7 (){}
    public static void main(String[] args) {
        
	{
	    class Local {}
	}
	class Local {}
    
    }
}
