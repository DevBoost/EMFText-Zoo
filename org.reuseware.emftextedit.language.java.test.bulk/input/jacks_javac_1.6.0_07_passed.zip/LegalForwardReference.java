
public class LegalForwardReference {
  void foo() { a = 1; }
  int a;
}
