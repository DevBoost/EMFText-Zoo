
public class T1414p8 {
    T1414p8 (){}
    public static void main(String[] args) {
        
        switch (args.length) {
            case 0: break;
        }
    
    }
}
