
public class T1418e2 {
    T1418e2 (){}
    public static void main(String[] args) {
        
        synchronized (new Object()) {}
    
    }
}
