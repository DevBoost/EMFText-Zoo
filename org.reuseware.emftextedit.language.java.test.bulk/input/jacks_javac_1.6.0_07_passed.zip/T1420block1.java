
public class T1420block1 {
    T1420block1 (){}
    public static void main(String[] args) {
        
        {}
        int i;
    
    }
}
