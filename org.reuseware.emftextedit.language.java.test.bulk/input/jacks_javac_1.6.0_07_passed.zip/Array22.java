
package pkg;
public class Array22 {
    public static A[] array;
    static class A {}
}
    