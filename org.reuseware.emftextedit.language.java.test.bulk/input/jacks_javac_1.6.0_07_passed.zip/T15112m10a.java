
package p1;
public class T15112m10a {
    protected int i;
}
    