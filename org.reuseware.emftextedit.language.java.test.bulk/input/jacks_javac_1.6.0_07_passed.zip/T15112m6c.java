
package p1;
class T15112m6a {
    protected int i;
}
interface T15112m6b {
    int i = 1;
}
public class T15112m6c extends T15112m6a implements T15112m6b {}
    