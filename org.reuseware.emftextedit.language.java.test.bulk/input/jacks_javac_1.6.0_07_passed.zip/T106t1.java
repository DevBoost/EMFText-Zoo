
public class T106t1 {
    T106t1 (){}
    public static void main(String[] args) {
        
        short s = 1;
        int[] ia = { s, '1' };
    
    }
}
