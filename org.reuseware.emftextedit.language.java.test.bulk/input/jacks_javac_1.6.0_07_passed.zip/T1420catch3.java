
public class T1420catch3 {
    T1420catch3 (){}
    public static void main(String[] args) {
        
        try {
            throw new Exception();
        } catch (Exception e) {
        }
    
    }
}
