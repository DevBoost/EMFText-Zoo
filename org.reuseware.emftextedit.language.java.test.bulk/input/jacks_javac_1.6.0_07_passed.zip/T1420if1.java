
public class T1420if1 {
    T1420if1 (){}
    public static void main(String[] args) {
        
        if (true)
            return;
        int i;
    
    }
}
