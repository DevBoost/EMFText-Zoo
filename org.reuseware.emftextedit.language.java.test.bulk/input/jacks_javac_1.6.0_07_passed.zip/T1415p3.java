
public class T1415p3 {
    T1415p3 (){}
    public static void main(String[] args) {
        
        int i=0;
        while (++i<10)
            continue;
    
    }
}
