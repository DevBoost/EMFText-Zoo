
public class T147scope1 {
    T147scope1 (){}
    public static void main(String[] args) {
        
        int i, j;
        label: i = 1;
        label: j = 1;
    
    }
}
