
public class T1510u3 {
    T1510u3 (){}
    public static void main(String[] args) {
        
	Object o = new int[1][2];
    
    }
}
