
public class T1513t1 {
    T1513t1 (){}
    public static void main(String[] args) {
        
	String[] s = {""};
	s[0].length();
	s[0].valueOf(1);
    
    }
}
