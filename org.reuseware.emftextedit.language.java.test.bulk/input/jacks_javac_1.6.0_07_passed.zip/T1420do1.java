
public class T1420do1 {
    T1420do1 (){}
    public static void main(String[] args) {
        
        boolean b = true;
        do {} while (b);
        int i;
    
    }
}
