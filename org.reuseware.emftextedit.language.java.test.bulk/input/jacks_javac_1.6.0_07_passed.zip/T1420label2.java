
public class T1420label2 {
    T1420label2 (){}
    public static void main(String[] args) {
        
        a: break a;
        int i;
    
    }
}
