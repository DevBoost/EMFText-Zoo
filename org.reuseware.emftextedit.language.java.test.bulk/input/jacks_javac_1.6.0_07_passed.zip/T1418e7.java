
public class T1418e7 {
    T1418e7 (){}
    public static void main(String[] args) {
        
        synchronized ((String) null) {}
    
    }
}
