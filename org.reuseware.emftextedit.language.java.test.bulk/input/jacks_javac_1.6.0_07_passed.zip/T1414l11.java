
public class T1414l11 {
    T1414l11 (){}
    public static void main(String[] args) {
        
        a: switch (args.length) {
            case 0: break a;
        }
    
    }
}
