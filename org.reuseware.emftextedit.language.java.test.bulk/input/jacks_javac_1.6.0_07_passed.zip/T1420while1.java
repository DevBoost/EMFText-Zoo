
public class T1420while1 {
    T1420while1 (){}
    public static void main(String[] args) {
        
        boolean b = true;
        while (b);
        int j;
    
    }
}
