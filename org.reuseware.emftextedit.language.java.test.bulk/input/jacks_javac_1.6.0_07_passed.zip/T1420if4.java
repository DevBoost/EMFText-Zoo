
public class T1420if4 {
    T1420if4 (){}
    public static void main(String[] args) {
        
        if (false)
            ;
        else
            return;
        int i;
    
    }
}
