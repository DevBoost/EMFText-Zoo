
public class EmptyNativeMethodBody {
    public native void foo();
}
