
public class T106s2 {
    T106s2 (){}
    public static void main(String[] args) {
        
        int[] ia = { 1 };
    
    }
}
