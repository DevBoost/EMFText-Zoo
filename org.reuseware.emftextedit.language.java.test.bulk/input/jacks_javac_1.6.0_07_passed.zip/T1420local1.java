
public class T1420local1 {
    T1420local1 (){}
    public static void main(String[] args) {
        
        class bar {}
        int i;
    
    }
}
