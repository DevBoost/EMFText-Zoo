
class T15153t7 {
    T15153t7 (){}
    void foo() {
        long n1 = +1L;
    }
}
