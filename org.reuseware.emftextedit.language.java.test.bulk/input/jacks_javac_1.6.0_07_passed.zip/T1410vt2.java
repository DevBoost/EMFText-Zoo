
class T1410vt2 {
    T1410vt2 (){}
    void foo(byte i) {
        switch (i) {
        }
    }
}
