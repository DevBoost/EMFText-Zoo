
public class T1414l9 {
    T1414l9 (){}
    public static void main(String[] args) {
        
        int i=0;
        a: while (++i<10) {
            break a;
        }
    
    }
}
