
package pkg;
public class Array5 {
    private static class A {}
}
    