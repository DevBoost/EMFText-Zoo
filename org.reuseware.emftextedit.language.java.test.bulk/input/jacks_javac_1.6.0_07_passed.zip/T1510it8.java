
public class T1510it8 {
    T1510it8 (){}
    public static void main(String[] args) {
        
        Object[] oa = new Object[] { null };
    
    }
}
