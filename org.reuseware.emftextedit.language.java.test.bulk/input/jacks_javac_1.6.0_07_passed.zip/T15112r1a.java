
package p1;
public class T15112r1a {
    public T15112r1a(String s) { b = s; }
    protected static String a = "1";
    protected String b;
}
    