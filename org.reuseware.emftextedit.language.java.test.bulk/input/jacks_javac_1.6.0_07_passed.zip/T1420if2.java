
public class T1420if2 {
    T1420if2 (){}
    public static void main(String[] args) {
        
        int i;
        if (false)
           i = 1;
    
    }
}
