
public class NoExpressionReturnInVoid {
    public void foo() { return; }
}
