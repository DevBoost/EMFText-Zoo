
class T15142t7 {
    double d = 1, d2 = d--;
}
