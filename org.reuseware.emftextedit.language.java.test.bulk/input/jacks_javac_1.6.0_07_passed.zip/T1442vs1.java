
public class T1442vs1 {
    T1442vs1 (){}
    public static void main(String[] args) {
        
        int i = (i = 1) + i;
    
    }
}
