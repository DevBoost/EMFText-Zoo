
package p1;
public class T15112m9a {
    protected int i;
}
    