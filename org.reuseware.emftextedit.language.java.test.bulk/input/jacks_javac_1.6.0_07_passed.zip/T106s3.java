
public class T106s3 {
    T106s3 (){}
    public static void main(String[] args) {
        
        int[] ia = { 1, 2 };
    
    }
}
