
public class T1420while7 {
    T1420while7 (){}
    public static void main(String[] args) {
        
        boolean b = false;
        while (b) b = false;
        int i;
    
    }
}
