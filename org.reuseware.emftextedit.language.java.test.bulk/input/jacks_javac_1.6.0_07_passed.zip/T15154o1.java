
class T15154o1 {
    
        T15154o1() {}
        int i, j = -i & 0;
    
}
