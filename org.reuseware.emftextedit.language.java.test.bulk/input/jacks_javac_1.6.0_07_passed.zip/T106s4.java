
public class T106s4 {
    T106s4 (){}
    public static void main(String[] args) {
        
        int[] ia = { , };
    
    }
}
