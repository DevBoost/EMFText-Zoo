
class T15141t6 {
    float f = 1, f2 = f++;
}
