
class T15153o1 {
    
        T15153o1() {}
        int i, j = +i & 0;
    
}
