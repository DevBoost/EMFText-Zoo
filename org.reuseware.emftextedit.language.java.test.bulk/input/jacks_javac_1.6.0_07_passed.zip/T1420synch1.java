
public class T1420synch1 {
    T1420synch1 (){}
    public static void main(String[] args) {
        
        synchronized (args) {}
        int i;
    
    }
}
