
class T1417n3 {
    

        void m() {

            new Object() {{ if (true) throw null; }};

        }

    
}
