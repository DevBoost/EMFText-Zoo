
class T1419e12 {
    
	void m() throws Exception {
	    try {
	    } finally {
		throw new Exception();
	    }
	}
    
}
