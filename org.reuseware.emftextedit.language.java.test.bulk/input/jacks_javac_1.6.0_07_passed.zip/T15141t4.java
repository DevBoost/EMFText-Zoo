
class T15141t4 {
    int i = 1, i2 = i++;
}
