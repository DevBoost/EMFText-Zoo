
package p1;
public class T15112m2a {
    protected int i;
}
    