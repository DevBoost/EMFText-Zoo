
public class T1510is6 {
    T1510is6 (){}
    public static void main(String[] args) {
        
        int[][] iaa = new int[][] { {1}, {2} };
    
    }
}
