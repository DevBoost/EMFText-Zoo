
public class T149ee13 {
    T149ee13 (){}
    public static void main(String[] args) {
        
        final long aconst = 0L;
        long anonconst = 1L;

        if (anonconst == aconst)
            ;
    
    }
}
