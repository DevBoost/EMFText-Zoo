
class T1410ac1 {
    T1410ac1 (){}
    void foo(int i) {
        switch (i) {
            case 0:
                                  break;
                                case 1:
                                  break;
        }
    }
}
