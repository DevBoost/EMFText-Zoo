
public class T1415p7 {
    T1415p7 (){}
    public static void main(String[] args) {
        
        int i=0;
        do {
            continue;
        } while (++i<10);
    
    }
}
