
public class T149ee6 {
    T149ee6 (){}
    public static void main(String[] args) {
        
        if ((short) 0 == (short) 1)
            ;
    
    }
}
