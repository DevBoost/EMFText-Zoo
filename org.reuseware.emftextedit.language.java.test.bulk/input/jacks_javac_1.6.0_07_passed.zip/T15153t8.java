
class T15153t8 {
    T15153t8 (){}
    void foo() {
        float n1 = +1f;
    }
}
