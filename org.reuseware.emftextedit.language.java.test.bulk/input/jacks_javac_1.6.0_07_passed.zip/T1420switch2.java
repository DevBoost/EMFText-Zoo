
public class T1420switch2 {
    T1420switch2 (){}
    public static void main(String[] args) {
        
        switch (args.length) {}
        int i;
    
    }
}
