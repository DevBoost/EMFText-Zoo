
package pkg;
public class Array28 {
    public static A[] array;
    public static class A {}
}
    