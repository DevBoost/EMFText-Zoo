
public class T149ee5 {
    T149ee5 (){}
    public static void main(String[] args) {
        
        final byte aconst = 0;
        byte anonconst = 1;

        if (anonconst == aconst)
            ;
    
    }
}
