
public class T1415p5 {
    T1415p5 (){}
    public static void main(String[] args) {
        
        for (int i=0; i<10; ++i) {
            continue;
        }
    
    }
}
