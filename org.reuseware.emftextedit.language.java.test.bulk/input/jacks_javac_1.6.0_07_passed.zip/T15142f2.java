
public class T15142f2 {
    T15142f2 (){}
    public static void main(String[] args) {
        
	final int i;
	if (false)
	    i--;
    
    }
}
