
public class T1510is4 {
    T1510is4 (){}
    public static void main(String[] args) {
        
        int[] ia = new int[] { , };
    
    }
}
