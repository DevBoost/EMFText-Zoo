
package p1;
public class T15123rm4a {
    protected void m() {
	System.out.print("a ");
    }
}
    