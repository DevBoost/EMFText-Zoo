package org.andromda.metafacades.emf.uml2;

import org.eclipse.uml2.Slot;

public interface LinkEnd extends Slot
{
}
