package org.andromda.metafacades.emf.uml2;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.Destination.
 *
 * @see org.andromda.metafacades.uml.Destination
 */
public class DestinationLogicImpl
    extends DestinationLogic
{

    public DestinationLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}