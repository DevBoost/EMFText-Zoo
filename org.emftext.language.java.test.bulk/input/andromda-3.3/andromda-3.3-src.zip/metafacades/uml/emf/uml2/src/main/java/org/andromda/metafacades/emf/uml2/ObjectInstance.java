package org.andromda.metafacades.emf.uml2;

import org.eclipse.uml2.InstanceSpecification;

public interface ObjectInstance extends InstanceSpecification
{
}
