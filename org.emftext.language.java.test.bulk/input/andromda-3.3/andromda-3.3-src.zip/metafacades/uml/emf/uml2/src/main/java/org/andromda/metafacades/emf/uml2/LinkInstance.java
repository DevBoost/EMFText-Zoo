package org.andromda.metafacades.emf.uml2;

import org.eclipse.uml2.InstanceSpecification;

public interface LinkInstance extends InstanceSpecification
{
}
