package org.andromda.metafacades.emf.uml2;


/**
 * MetafacadeLogic implementation for
 * org.andromda.metafacades.uml.ObjectFlowStateFacade.
 * TODO: need to be implemented
 *
 * @see org.andromda.metafacades.uml.ObjectFlowStateFacade
 */
public class ObjectFlowStateFacadeLogicImpl
    extends ObjectFlowStateFacadeLogic
{
    public ObjectFlowStateFacadeLogicImpl(
        final Object metaObject,
        final String context)
    {
        super(metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.ObjectFlowStateFacade#getType()
     */
    protected java.lang.Object handleGetType()
    {
        // TODO: add your implementation here!
        return null;
    }
}