package org.andromda.metafacades.uml14;


/**
 * MetafacadeLogic implementation.
 *
 * @see org.andromda.metafacades.uml.ArgumentFacade
 */
public class ArgumentFacadeLogicImpl
    extends ArgumentFacadeLogic
{
    public ArgumentFacadeLogicImpl(
        org.omg.uml.behavioralelements.commonbehavior.Argument metaObject,
        java.lang.String context)
    {
        super(metaObject, context);
    }
}