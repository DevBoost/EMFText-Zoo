package org.andromda.metafacades.uml14;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.Queue.
 *
 * @see org.andromda.metafacades.uml.Queue
 */
public class QueueLogicImpl
    extends QueueLogic
{

    public QueueLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}