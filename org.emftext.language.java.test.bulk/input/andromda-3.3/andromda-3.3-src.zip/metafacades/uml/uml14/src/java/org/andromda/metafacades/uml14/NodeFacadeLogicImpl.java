package org.andromda.metafacades.uml14;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.NodeFacade.
 *
 * @see org.andromda.metafacades.uml.NodeFacade
 */
public class NodeFacadeLogicImpl
    extends NodeFacadeLogic
{

    public NodeFacadeLogicImpl (org.omg.uml.foundation.core.Node metaObject, String context)
    {
        super (metaObject, context);
    }
}