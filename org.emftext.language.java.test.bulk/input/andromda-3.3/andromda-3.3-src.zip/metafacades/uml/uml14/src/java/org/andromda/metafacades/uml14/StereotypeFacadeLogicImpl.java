package org.andromda.metafacades.uml14;

/**
 * MetafacadeLogic implementation.
 *
 * @see org.andromda.metafacades.uml.StereotypeFacade
 */
public class StereotypeFacadeLogicImpl
        extends StereotypeFacadeLogic
{
    // ---------------- constructor -------------------------------

    public StereotypeFacadeLogicImpl(org.omg.uml.foundation.core.Stereotype metaObject, java.lang.String context)
    {
        super(metaObject, context);
    }
}
