package org.andromda.core.server;

import org.andromda.core.configuration.Configuration;


/**
 * The AndroMDA server instance.  The server
 * is configured from an AndroMDA {@link Configuration}
 * instance.
 *
 * @see Client
 * @author Chad Brandon
 */
public interface Server
{
    /**
     * Starts the server instance listening for requests with the given
     * configuration.
     */
    public void start(final Configuration configuration);
}