package org.andromda.core.metafacade;


/**
 * Fake metafacade number 4 (just used for testing the MetafacadeMappings).
 *
 * @author Chad Brandon
 */
public interface Metafacade4
{
}