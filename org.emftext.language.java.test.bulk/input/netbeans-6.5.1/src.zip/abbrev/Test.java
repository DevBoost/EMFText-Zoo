/*
 * Test.java
 *
 * Created on April 18, 2002, 2:38 PM
 */

package abbrev;

/**
 *
 * @author  Jan Lahoda
 */
public class Test {
    
    /** Creates a new instance of Test */
    public Test() {
    }
    
    public static void main(String[] args) {
        
    }
    
}
