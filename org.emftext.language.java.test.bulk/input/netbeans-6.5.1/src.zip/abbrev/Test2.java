package abbrev;

import java.util.Collection;
import java.util.List;

public class Test2 {
    
    /**
     * javadoc comment
     * 
     * 
     * @param col
     */
    public void method(Collection<Integer> col) {
        List<String> list = null;
        
    }

}
