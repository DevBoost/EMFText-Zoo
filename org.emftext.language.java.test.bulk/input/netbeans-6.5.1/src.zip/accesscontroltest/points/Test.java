package accesscontroltest.points;

public class Test {
    public String field;
    public static String staticField;
    public static void main(String[] args) {

    }
}
