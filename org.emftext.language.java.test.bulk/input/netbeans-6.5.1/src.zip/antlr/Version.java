package antlr;

public class Version {  
	public static final String version    = "2";
	public static final String subversion = "7";
	public static final String patchlevel = "7";
	public static final String datestamp  = "2006-01-29";
	public static final String project_version = "Sun-2.7.7(NoEx) ("+datestamp+")";
}
