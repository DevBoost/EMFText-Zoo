package org.foo.myapp;
public class SomeFile {
    public SomeFile() {
    }
    public static void main(String[] x) {
        System.out.println("Running SomeFile!");
    }
}
