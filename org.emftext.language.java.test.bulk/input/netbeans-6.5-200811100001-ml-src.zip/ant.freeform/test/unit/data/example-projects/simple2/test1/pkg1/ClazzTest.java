package pkg1;
public class ClazzTest {}
