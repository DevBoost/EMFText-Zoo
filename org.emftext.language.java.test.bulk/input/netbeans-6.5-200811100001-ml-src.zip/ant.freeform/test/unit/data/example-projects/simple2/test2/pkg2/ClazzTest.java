package pkg2;
public class ClazzTest {}
