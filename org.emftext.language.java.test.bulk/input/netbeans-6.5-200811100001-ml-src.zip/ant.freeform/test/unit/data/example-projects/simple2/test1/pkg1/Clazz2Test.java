package pkg1;
public class Clazz2Test {}
