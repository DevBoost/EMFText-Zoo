package org.bar;
public class Bar {}
