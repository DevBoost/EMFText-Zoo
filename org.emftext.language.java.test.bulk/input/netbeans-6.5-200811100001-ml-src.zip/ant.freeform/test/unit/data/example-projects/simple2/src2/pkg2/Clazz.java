package pkg2;
public class Clazz {}
