package org.foo;
public class Foo {}
