package pkg1;
class Clazz2 {}
