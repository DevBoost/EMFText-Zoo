package javaapplication1;

public class Main {
}
