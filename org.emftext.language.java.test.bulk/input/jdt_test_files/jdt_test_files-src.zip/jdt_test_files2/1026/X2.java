public enum X2 implements I {
	;
	public void test() {}
}
interface I { void test(); }
