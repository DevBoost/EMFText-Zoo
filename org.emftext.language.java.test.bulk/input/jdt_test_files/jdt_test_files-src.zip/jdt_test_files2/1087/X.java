public enum X {
	INPUT {
		@Override
		public X getReverse() {
			return OUTPUT;
		}
	},
	OUTPUT {
		@Override
		public X getReverse() {
			return INPUT;
		}
	},
	INOUT {
		@Override
		public X getReverse() {
			return INOUT;
		}
	};
	X(){}
	public abstract X getReverse();
}
