public class X {
	public static void main(String[] s) {
		int[] ints = {0, 1, 2};
		for(Integer i : ints) {
			System.out.print(i);
		}
	}
}
