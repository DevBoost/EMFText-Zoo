import java.util.*;	
public class Portfolio {	
	String name;	
	public Portfolio(String buf) {	
		TokenBuffer tbuf = new TokenBuffer();	
		switch (1) {	
			case TokenBuffer.T_NAME :	
				name = "figi";	
		}	
	}	
	String getName() {	
		return name;	
	}	
	class TokenBuffer {	
		static final int T_NAME = 3;	
	}	
}	
