public enum X {
	A,B
	;
	public static void main(String[] args) {
		try {
			System.out.println(X.valueOf(null));
		} catch (NullPointerException e) {
			System.out.println("NullPointerException");
		} catch (IllegalArgumentException e) {
			System.out.println("IllegalArgumentException");
		}
	}
}
