public class X {

	enum Test1 {
		V;
	}
	Object foo() {
		return this;
	}

	static class Sub extends X {
		@Override
		Test1 foo() {
			return Test1.V;
		}
	}
}
