public class X extends q.Y { 
	void bar(){ Object o = someObject; } 
	public static void main(String[] argv){ 
		new X().bar();
		System.out.println("SUCCESS");
	}
}
