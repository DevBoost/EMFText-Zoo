public class Y1 {
	/** */
	protected X field = new X() {
		/** Invalid javadoc comment in anonymous class */
		void foo(String str) {}
	};
}
