public class X {
	void foo(int x, String str) {}
}
