public enum X3b implements I {
	A() { public void test() {} };
	public abstract void test();
}
interface I { void test(); }
