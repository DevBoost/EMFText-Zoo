public enum X2a implements I {
	A;
	public void test() {}
}
interface I { void test(); }
