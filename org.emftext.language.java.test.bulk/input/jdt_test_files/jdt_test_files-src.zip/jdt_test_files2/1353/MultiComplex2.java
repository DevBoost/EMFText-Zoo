public class MultiComplex2 {
	public interface AbstractTask extends Runnable {
		public void run();
		public String taskName();		
	}
	
	public static void main(String argv[]){
		try {
			new MultiComplex2().performTasks(3);
		}
		catch(InterruptedException e){};
	}
	void notifyCompleted(AbstractTask task) {
	}
	void notifyCompletion(AbstractTask task, int percentage) {
	}
	void notifyExecutionEnd() {
		System.out.println("EXECUTION FINISHED");
	}
	void notifyExecutionStart() {
		System.out.println("EXECUTION STARTING");
	}
		void performTasks(final int maxTasks) throws java.lang.InterruptedException {
		Thread workers[] = new Thread[maxTasks];
		AbstractTask tasks[] = new AbstractTask[maxTasks];
		final int maxIteration = 5;
		// Local Task
		class Task implements AbstractTask {
				String taskName;
				Task(String aName) {
					taskName = aName;
				}
				public String taskName() { 
					return taskName; 
				}
	
				public void run() {
					MultiComplex2.this.notifyCompletion(this,0); 
					for(int j = 0; j < maxIteration; j++)
						MultiComplex2.this.notifyCompletion(this,  (int)((float) (j + 1) / maxIteration * 100));
				}
		};
		notifyExecutionStart();
		
		// Creating and launching the tasks
		for (int ii = 0; ii < maxTasks; ii++) {
			final int i = ii;
			tasks[i] = new Task(String.valueOf(i + 1)) {			
				public String taskName() { 
					return super.taskName() +  " of " + maxTasks; }
				public void run() {
					super.run();
					MultiComplex2.this.notifyCompleted(this);
				}		
			};
			workers[i] = new Thread(tasks[i],tasks[i].taskName());
			workers[i].start();
		}
		// Waiting for *all* tasks to be ended
		for (int i = 0; i < tasks.length; i++)
			workers[i].join();
		notifyExecutionEnd();
	}
}
