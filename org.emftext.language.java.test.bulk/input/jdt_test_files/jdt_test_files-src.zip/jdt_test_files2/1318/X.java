public class X implements I {}
class Y extends X implements I, J {}interface I {}
interface J {}
