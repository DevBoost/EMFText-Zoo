public class X {
	public static void main(String[] s) {
		test(new Character('c'));
	}
	public static void test(char c) { System.out.print('y'); }
}
