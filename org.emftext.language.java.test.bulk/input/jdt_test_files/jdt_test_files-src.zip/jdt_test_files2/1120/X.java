public class X {
	public static void main(String[] s) {
		test(new Float(0.0f));
	}
	public static void test(float f) { System.out.print('y'); }
}
