package e;
public enum T {
	PHILIPPE(37) {
		public boolean isManager() {
			return true;
		}
	},
	DAVID(27),
	JEROME(33),
	OLIVIER(35),
	KENT(40),
	YODA(41),
	FREDERIC;
	final static int OLD = 41;

   enum Role { M, D }

   int age;
	Role role;

	T() { this(OLD); }
	T(int age) {
		this.age = age;
	}
	public int age() { return this.age; }
	public boolean isManager() { return false; }
	void setRole(boolean mgr) {
		this.role = mgr ? Role.M : Role.D;
	}
}
