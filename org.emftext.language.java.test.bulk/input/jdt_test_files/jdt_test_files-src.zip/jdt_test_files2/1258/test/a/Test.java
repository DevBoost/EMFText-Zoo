package test.a;
/**
 * @see Inner
 * @see Test.Inner
 */
public class Test {
	class Inner {}
}
