package p2;	
import p1.*;	
public class c2 extends c1 {	
	public c1a myC1a;	
	{	
		myC1a = new c1a();	
		myC1a.foo();	
	}	
}	
