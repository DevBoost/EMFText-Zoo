package p;
public class Y {
  public static void main(String[] args) {
    int clockend = 0;
    clockend += 128;
    if(clockend < 0) {
      System.out.println(clockend);
      System.exit(-1);
    }
  }
}
