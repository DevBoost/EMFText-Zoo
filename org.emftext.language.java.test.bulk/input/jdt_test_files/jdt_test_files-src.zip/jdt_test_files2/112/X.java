import java.util.Vector;
public class X {
	/**
	 * Valid local methods references
	 * 
	 * @see X#smr_foo() Valid local method reference
	 * @see X#smr_foo(boolean, int, byte, short, char, long, float, double) Valid local method reference
	 * @see X#smr_foo(boolean,int,byte,short,char,long,float,double) Valid local method reference
	 * @see X#smr_foo(boolean b, int i, byte y, short s, char c, long l, float f, double d) Valid local method reference
	 * @see X#smr_foo(boolean a1,int a2,byte a3,short a4,char a5,long a6,float a7,double a8) Valid local method reference
	 * @see X#smr_foo(String, String, int) Valid local method reference
	 * @see X#smr_foo(java.lang.String, String, int) Valid local method reference   
	 * @see X#smr_foo(String, java.lang.String, int) Valid local method reference   
	 * @see X#smr_foo(java.lang.String, java.lang.String, int) Valid local method reference   
	 * @see X#smr_foo(String x,String y,int z) Valid local method reference   
	 * @see X#smr_foo(java.lang.String x,String y, int z) Valid local method reference   
	 * @see X#smr_foo(String x,java.lang.String y,int z) Valid local method reference   
	 * @see X#smr_foo(java.lang.String x,java.lang.String y,int z) Valid local method reference   
	 * @see X#smr_foo(java.util.Hashtable,java.util.Vector,boolean) Valid local method reference
	 * @see X#smr_foo(java.util.Hashtable,Vector,boolean) Valid local method reference
	 * @see X#smr_foo(java.util.Hashtable a, java.util.Vector b, boolean c) Valid local method reference
	 * @see X#smr_foo(java.util.Hashtable a, Vector b, boolean c) Valid local method reference
	 */  
	public void s_foo() {
	}

	// Empty methods definition for reference
	public void smr_foo() {
	}
	public void smr_foo(boolean b, int i, byte y, short s, char c, long l, float f, double d) {
	}
	public void smr_foo(String str1, java.lang.String str2, int i) {
	}
	public void smr_foo(java.util.Hashtable h, java.util.Vector v, boolean b) {
	}
}
