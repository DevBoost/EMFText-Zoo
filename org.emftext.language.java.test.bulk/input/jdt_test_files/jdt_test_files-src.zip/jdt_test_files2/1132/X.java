public class X {
	public static void main(String[] s) {
		Object o = Y.test();
		System.out.print(o);
	}
}
class Y {
	public static int test() { return 1; }
}
