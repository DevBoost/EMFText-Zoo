package org.eclipse.curiosity;
public interface InterfaceA extends InterfaceBase {}
