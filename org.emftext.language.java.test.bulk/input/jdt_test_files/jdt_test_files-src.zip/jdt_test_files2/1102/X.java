public class X {
	public static void main(String[] s) {
		test('b');
	}
	public static void test(Character c) { System.out.print('y'); }
}
