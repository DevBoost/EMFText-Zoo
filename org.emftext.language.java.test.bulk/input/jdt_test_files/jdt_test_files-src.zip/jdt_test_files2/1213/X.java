class A<T> {
        public T foo;
}

public class X {
        public static void main(String[] args) {
            A<Long> a = new A<Long>();
	         long s = a.foo.MAX_VALUE;
            System.out.println("SUCCESS");
        }
}
