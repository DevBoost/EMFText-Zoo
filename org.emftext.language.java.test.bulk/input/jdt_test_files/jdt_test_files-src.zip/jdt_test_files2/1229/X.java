public class X {
	public static void main(String[] args) {
		Integer i = 0;
		if (i != null) {
			System.out.println("SUCCESS");
		}
	}
}
