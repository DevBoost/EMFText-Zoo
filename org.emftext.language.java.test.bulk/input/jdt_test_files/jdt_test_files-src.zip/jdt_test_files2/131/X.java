import java.io.IOException;
public class X {
	public void foo() throws IOException {}
}
