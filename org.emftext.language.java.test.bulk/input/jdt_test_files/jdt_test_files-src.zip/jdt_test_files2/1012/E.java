	/**
	 * Valid javadoc
	 * @author ffr
	 */
public enum E {
	/** Valid javadoc */
	TEST,
	/** Valid javadoc */
	VALID;
	/** Valid javadoc */
	public void foo() {}
}
