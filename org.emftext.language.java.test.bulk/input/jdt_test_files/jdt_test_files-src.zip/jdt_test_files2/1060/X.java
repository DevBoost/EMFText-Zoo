import p.BeanName;
public class X {
	Object o = BeanName.CreateStepApiOperation;
}