public class Y2 { 
	public static void main(String[] argv){ 
		if (new Y2().foo(45) == 45) 
			System.out.println("SUCCESS"); 
		else 
			System.out.println("FAILED"); 
	} 
	int foo(final int i){ 
		class B { 
			int foo(){ 
				return new C().foo(); 
			} 
			class C { 
				int foo(){ return i; } 
			} 
		}; 
		return new B().foo(); 
	} 
} 
