public enum TestEnum {
	RED, GREEN, BLUE; 
    static int test = 0;  

    TestEnum() {
        new Object() {
			{ TestEnum.test=10; }
		};
    }
}
