public class X {
	public static void main(String[] s) {
		test(Long.MAX_VALUE);
	}
	public static void test(Long l) { System.out.print('y'); }
}
