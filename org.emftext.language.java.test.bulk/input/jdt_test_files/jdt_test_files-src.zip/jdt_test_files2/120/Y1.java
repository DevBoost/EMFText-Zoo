public class Y1 {
	/** */
	protected X field = new X() {
		/**
		 * Valid javadoc comment in anonymous class.
		 * @param str String
		 * @return int
		 */
		int bar(String str) {
			return 10;
		}
	};
}
