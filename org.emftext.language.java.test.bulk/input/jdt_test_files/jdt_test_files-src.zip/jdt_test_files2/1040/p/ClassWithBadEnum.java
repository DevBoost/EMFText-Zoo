package p;

public class ClassWithBadEnum {
	public interface EnumInterface<T extends Object> {
	    public T getMethod();
	}

	public enum EnumClass implements EnumInterface<String> {
		ENUM1 { public String getMethod() { return "ENUM1";} },
		ENUM2 { public String getMethod() { return "ENUM2";} };
	}
	private EnumClass enumVar; 
	public EnumClass getEnumVar() {
		return enumVar;
	}
	public void setEnumVar(EnumClass enumVar) {
		this.enumVar = enumVar;
	}

	public static void main(String... argv) {
		int a = 1;
		ClassWithBadEnum badEnum = new ClassWithBadEnum();
		badEnum.setEnumVar(ClassWithBadEnum.EnumClass.ENUM1);
		// Should fail if bug manifests itself because there will be two getInternalValue() methods
		// one returning an Object instead of a String
		String s3 = badEnum.getEnumVar().getMethod();
		System.out.println(s3);
	}
}  
