public enum E {
	/**
	 * @see E
	 * @see #VALID
	 */
	TEST,
	/**
	 * @see E#TEST
	 * @see E
	 */
	VALID;
	/**
	 * @param x the object
	 * @return String
	 * @see Object
	 */
	public String val(Object x) { return x.toString(); }
}
