public class Foo{
    public enum Rank {FIRST,SECOND,THIRD}
    public void setRank(Rank rank){}
}
