public class X {	
    int i;	
    X(int j) {	
    	i = j;	
    }	
    X() {	
    }	
    class B extends X {	
        B() {	
            this.i = X.this.i;	
        }	
    }	
    public static void main(String[] args) {	
        X a = new X(3);	
        System.out.print(a.i + " ");	
        System.out.print(a.new B().i);	
	}	
}	
