class A<T> {
        public T foo(Object o) {
                return (T) o; // should get unchecked warning
        }
}

public class X {
        public static void main(String[] args) {
                A<Long> a = new A<Long>();
                try {
	                long s = a.foo(new Object());
                } catch(ClassCastException e) {
                	System.out.println("SUCCESS");
                	return;
                }
            	System.out.println("FAILED");
        }
}
