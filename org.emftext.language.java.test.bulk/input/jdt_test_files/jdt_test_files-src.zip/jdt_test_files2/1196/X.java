public class X {
	public static void main(String[] args) {
		foo1();
		foo2();
		foo3();
		foo4();
		System.out.println("[done]");
	}
	static void foo1() {
		Object x = true ? true : "";
		System.out.print("[1:"+ x + "," + x.getClass().getCanonicalName() + "]");
	}
	static void foo2() {
		Object x = Boolean.TRUE != null ? true : "";
		System.out.print("[2:"+ x + "," + x.getClass().getCanonicalName() + "]");
	}
	static void foo3() {
		Object x = false ? "" : false;
		System.out.print("[3:"+ x + "," + x.getClass().getCanonicalName() + "]");
	}
	static void foo4() {
		Object x = Boolean.TRUE == null ? "" : false;
		System.out.print("[4:"+ x + "," + x.getClass().getCanonicalName() + "]");
	}
}