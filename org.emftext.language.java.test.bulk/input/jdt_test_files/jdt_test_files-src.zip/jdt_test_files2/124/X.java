public class X {
	int x;
	public X(int i) {
		x = i;
	}
	/**
	 * @see #X(int)
	 */
	void foo() {
	}
}
