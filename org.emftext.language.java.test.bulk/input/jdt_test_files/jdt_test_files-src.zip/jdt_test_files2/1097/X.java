public enum X {
	BLEU, BLANC, ROUGE;
	final static int CST = 0;
    enum Member {
    	;
        Object obj1 = CST;
        Object obj2 = BLEU;
    }
}
