public class X {
	static class Y {
		enum E {}
	}
}