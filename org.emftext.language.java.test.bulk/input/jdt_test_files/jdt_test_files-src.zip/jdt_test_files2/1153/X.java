public class X {
   public static void main(String[] args) {
      if (new Integer(1) == new Integer(0)) {
         System.out.println();
      }
      System.out.print("SUCCESS");
   }
}