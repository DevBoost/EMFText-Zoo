package com.annot;

import static com.annot.TestType.CORRECTNESS;
import static java.lang.annotation.ElementType.METHOD;

import java.lang.annotation.Target;

@Target(METHOD)
public @interface Test {
	TestType type() default CORRECTNESS;
}