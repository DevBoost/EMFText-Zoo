public class X {
	char c = 'H';
	static void print(Character c) {
		System.out.print((char) c);
	}
	public static void main(String[] args) {
		X x = new X();
		print(++x.c);
		print(++x.c);
		System.out.println("done");
    }
}
