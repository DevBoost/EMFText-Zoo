package test;
import test.copy.VisibilityPublic;
public class X {
	/**
	 * Valid other package visible class methods references 
	 * 
	 * @see VisibilityPublic#vm_public() Valid ref to not visible method of other package class
	 * @see VisibilityPublic.VpPublic#vm_public() Valid ref to visible method of other package public inner class
	 */
	public void s_foo() {
	}
}
