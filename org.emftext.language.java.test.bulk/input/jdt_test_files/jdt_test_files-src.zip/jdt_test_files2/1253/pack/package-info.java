/**
 * Valid javadoc.
 * @see Test
 * @see Unknown
 * @see Test#foo()
 * @see Test#unknown()
 * @see Test#field
 * @see Test#unknown
 * @param unexpected
 * @throws unexpected
 * @return unexpected 
 * @deprecated accepted by javadoc.exe although javadoc 1.5 spec does not say that's a valid tag
 * @other-tags are valid
 */
package pack;
