/**
 * Invalid javadoc
 */
package pack;
public class Test {
	public int field;
	public void foo() {}
}
