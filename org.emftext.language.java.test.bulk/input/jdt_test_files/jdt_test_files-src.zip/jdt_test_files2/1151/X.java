public class X {

	public static void main(String[] args) {
		Boolean b = Boolean.TRUE;
		
		if (b && !b) {
			System.out.print("THEN");
		} else {
			System.out.print("ELSE");
		}
    }
}