package test;
public abstract class AbstractVisibility {
	private class AvcPrivate {
		private int avf_private = 10;
		public int avf_public = avf_private;
		private int avm_private() {
			avf_private = (new AvcPrivate()).avf_private;
			return avf_private;
		}
		public int avm_public() {
			return avm_private();
		}
	}
	public class AvcPublic {
		private int avf_private = 10;
		public int avf_public = avf_private;
		private int avm_private() {
			avf_private = (new AvcPrivate()).avf_private;
			return avf_private;
		}
		public int avm_public() {
			return avm_private();
		}
	}
	private int avf_private = 100;
	public int avf_public = avf_private;
	
	private int avm_private() {
		avf_private = (new AvcPrivate()).avf_private;
		return avf_private;
	}
	public int avm_public() {
		return avm_private();
	}
}
