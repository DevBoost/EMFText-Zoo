package test.copy;
class VisibilityPackage {
	private class VpPrivate {
		private int vf_private = 10;
		public int vf_public = vf_private;
		private int vm_private() {
			vf_private = (new VpPrivate()).vf_private;
			return vf_private;
		}
		public int vm_public() {
			return vm_private();
		}
	}
	public class VpPublic {
		private int vf_private = 10;
		public int vf_public = vf_private;
		private int vm_private() {
			vf_private = (new VpPrivate()).vf_private;
			return vf_private;
		}
		public int vm_public() {
			return vm_private();
		}
	}
	private int vf_private = 100;
	public int vf_public = vf_private;
	
	private int vm_private() {
		vf_private = (new VpPrivate()).vf_private;
		return vf_private;
	}
	public int vm_public() {
		return vm_private();
	}
}
