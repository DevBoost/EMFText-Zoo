public enum X {
	BLEU (0) {
	}
	;
	X() {
		this(0);
	}
	X(int i) {
	}
}
