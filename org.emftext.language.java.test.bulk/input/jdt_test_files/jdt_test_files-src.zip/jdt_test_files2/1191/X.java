class XSuper<T> {
	T value;
}
public class X extends XSuper<Integer>{
	public static void a(X x) {
		x.value--;
		--x.value;
		x.value -= 1;
		x.value = x.value - 1;
		System.out.println(x.value);
	}

	public static void main(final String[] args) {
		X x = new X();
		x.value = 5;
		a(x);
	}
}
