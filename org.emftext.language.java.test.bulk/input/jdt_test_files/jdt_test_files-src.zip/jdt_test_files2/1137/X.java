public class X {
	public static void main(String[] args) {
		Integer[] tab = new Integer[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		for (final int e : tab) {
			System.out.print(e);
		}
	}
}
