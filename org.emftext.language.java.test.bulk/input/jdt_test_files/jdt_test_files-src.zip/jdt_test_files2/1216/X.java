public class X {
	public static void main(String[] args) {
		if(new Integer(2) == 0) {
			System.out.println("FAILED");
		} else {
			System.out.println("SUCCESS");
		}
	}
}