public enum X {
	MONDAY {
		public void foo() {
		}
	};
	private X() {
	}
	public static void main(String[] args) {
	  System.out.println("SUCCESS");
	}
}
