package test.b;
/** 
 * @see Inner.Level2
 * @see Test.Inner.Level2
 */
public class Test {
	/** 
	 * @see Level2
	 * @see Test.Inner.Level2
	 */
	public class Inner {
		class Level2 {}
	}
}
