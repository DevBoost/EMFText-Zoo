enum EnumTest1 {
	;
	static int foo = EnumTest2.bar;
}
enum EnumTest2 {
	;
	static int bar = EnumTest1.foo;
}
