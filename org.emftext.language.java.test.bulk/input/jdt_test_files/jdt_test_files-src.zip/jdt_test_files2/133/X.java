public class X implements Comparable {

	/**
	 * Overridden method with return value and parameters.
	 * {@inheritDoc}
	 */
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

	/**
	 * Overridden method with return value and thrown exception.
	 * {@inheritDoc}
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	/**
	 * Implemented method (Comparable)  with return value and parameters.
	 * {@inheritDoc}
	 */
	public int compareTo(Object o) { return 0; }
}
