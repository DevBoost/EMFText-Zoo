public class Inner { 
	public static void main(String[] argv){ 
		new B().new C("hello"); 
		System.out.println("SUCCESS"); 
	} 
  class A { 	
    public A(String s){ this.s=s; }	
    String s;	
  }	
}	
class B {	
  class C extends Inner.A {	
    public C(String s){  B.this.inner.super(s); }   	
  }	
  Inner inner=new Inner();	
}	
