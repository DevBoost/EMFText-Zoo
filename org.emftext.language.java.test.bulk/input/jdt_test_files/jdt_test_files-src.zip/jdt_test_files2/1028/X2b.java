public enum X2b implements I {
	A() { public void test() {} };
	public void test() {}
}
interface I { void test(); }
