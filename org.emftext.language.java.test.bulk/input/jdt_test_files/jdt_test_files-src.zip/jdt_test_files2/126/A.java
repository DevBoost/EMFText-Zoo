public abstract class A {
	public A() { super(); }
}
