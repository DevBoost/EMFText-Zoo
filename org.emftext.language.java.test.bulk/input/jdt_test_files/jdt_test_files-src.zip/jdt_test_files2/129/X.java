/** */
public class X implements Comparable {
	/**
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Object o) {
		return 0;
	}
	/** @see Object#toString() */
	public String toString(){
		return "";
	}
}
