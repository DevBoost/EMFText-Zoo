class X {
	void foo() {}
}
