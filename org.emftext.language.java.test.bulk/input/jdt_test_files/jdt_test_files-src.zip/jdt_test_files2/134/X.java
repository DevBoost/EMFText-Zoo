import java.util.Vector;
public final class X {
	int bar(String str, int var, Vector list, char[] array) throws IllegalAccessException { return 0; }
	/**
	 * Valid method reference on several lines
	 * @see #bar(String str,
	 * 		int var,
	 * 		Vector list,
	 * 		char[] array)
	 */
	void foo() {}
}
