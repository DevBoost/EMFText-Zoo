import static test.E.TEST;
	/**
	 * Valid value = {@value test.E#VALID}
	 * Test value = {@value #TEST}
	 */
public class X {}
