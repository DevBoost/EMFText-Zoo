public enum X1b implements I {
	A() { void random() {} };
}
interface I {}
