public class X {

	public static void main(String[] args) {
	    Byte b = new Byte((byte)1);
	    Integer i = 0;
	    int n = b + i;
		System.out.println(n);
    }
}
