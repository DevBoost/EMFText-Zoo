class Z {
	public <A, B extends A> Z(A a, B b) {
	}
}