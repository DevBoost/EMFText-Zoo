class Wrapper< T >
{
    public T value;
}

public class X
{
    public static void main( final String[ ] args )
    {
        final Wrapper< Integer > wrap = new Wrapper< Integer >( );
        wrap.value = 0;
        wrap.value = wrap.value + 1; // works
        wrap.value++; // throws VerifyError
        wrap.value += 1; // throws VerifyError
    }
}
