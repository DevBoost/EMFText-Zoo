public class X extends Object implements Runnable {
	int interval = 5;
	public void run() {
		try {
			Thread.sleep(interval = interval + 100);
			Thread.sleep(interval += 100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new X().run();
	}
}
