public strictfp enum X {
	A, B;
	private X() {}
}
