final class Pair<F, S> {
	public F first;
	public S second;

	public static <F, S> Pair<F, S> create(F f, S s) {
		return new Pair<F, S>(f, s);
	}

	public Pair(final F f, final S s) {
		first = f;
		second = s;
	}
}

public class X {
	public void a() {
		Pair<Integer, Integer> p = Pair.create(1, 3);
		// p.first -= 1; // should be rejected ?
		p.first--;
		--p.first;
		p.first = p.first - 1;
		System.out.println(p.first);
	}

	public static void main(final String[] args) {
		new X().a();
	}
}
