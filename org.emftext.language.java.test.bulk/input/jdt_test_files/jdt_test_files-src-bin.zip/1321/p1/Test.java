package p1; 
public class Test { 
	public static void main(String[] arguments) { 
		new Test().foo(); 
	} 
	class M { 
	} 
	void foo(){ 
		class Y extends Secondary { 
			M m; 
		}; 
		System.out.println("SUCCESS");	
	} 
} 
class Secondary { 
	class M {} 
} 
