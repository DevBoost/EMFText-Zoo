public final class X {
	/**
	 * Now valid duplicated throws tag
	 * @throws IllegalArgumentException First comment
	 * @throws IllegalArgumentException Second comment
	 * @throws IllegalArgumentException Last comment
	 */
	void foo() throws IllegalArgumentException {}
}
