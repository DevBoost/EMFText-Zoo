public enum E {
	/**
	 * Test value: {@value #TEST}
	 */
	TEST,
	/**
	 * Valid value: {@value E#VALID}
	 */
	VALID;
	/**
	 * Test value: {@value #TEST}
	 * Valid value: {@value E#VALID}
	 * @param x the object
	 * @return String
	 */
	public String val(Object x) { return x.toString(); }
}
