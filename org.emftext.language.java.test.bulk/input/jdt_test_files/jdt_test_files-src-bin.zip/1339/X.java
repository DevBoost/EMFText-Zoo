public class X { 
	private X(){} 
	class Y extends X { 
	} 
	public static void main(String[] argv){	
		new X().new Y();	 				 
		System.out.println("SUCCESS");	 
	}										
} 
