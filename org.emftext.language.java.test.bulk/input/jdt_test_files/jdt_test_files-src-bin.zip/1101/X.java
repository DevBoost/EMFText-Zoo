public class X {
	public static void main(String[] s) {
		test((byte)127);
	}
	public static void test(Byte b) { System.out.print('y'); }
}
