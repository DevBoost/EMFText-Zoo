package test;
public class Visibility extends AbstractVisibility {
	private class VcPrivate {
		private int vf_private = 10;
		public int vf_public = vf_private;
		private int vm_private() {
			vf_private = (new VcPrivate()).vf_private;
			avf_private = vf_private;
			return vf_private+avf_private;
		}
		public int vm_public() {
			return vm_private();
		}
	};
	public class VcPublic {
		private int vf_private = 10;
		public int vf_public = vf_private;
		private int vm_private() {
			vf_private = (new VcPrivate()).vf_private;
			avf_private = vf_private;
			return vf_private+avf_private;
		}
		public int vm_public() {
			return vm_private();
		}
	};
	private int vf_private = 100;
	private int avf_private = 100;
	public int vf_public = vf_private;
	public int avf_public = vf_private;
	
	private int vm_private() {
		vf_private = (new VcPrivate()).vf_private;
		avf_private = vf_private;
		return vf_private+avf_private;
	}
	public int vm_public() {
		return vm_private();
	}
}
