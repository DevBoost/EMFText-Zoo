public class X {
	public static void main(String[] args) {
		Character cValue = new Character('c');
		if ('c' == cValue) System.out.println('y');
	}
}
