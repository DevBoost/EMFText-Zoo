package p1; 
public class Test { 
	public static void main(String[] arguments) { 
		new Test().foo(); 
	} 
	String bar = "FAILED";	void foo(){ 
		class Y extends Secondary { 
			String z = bar; 
		}; 
		System.out.println(new Y().z);	
	} 
} 
class Secondary { 
	String bar = "SUCCESS"; 
} 
