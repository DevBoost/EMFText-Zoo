public enum X implements I { 
	ROUGE;
	public void foo(A a) {}
}
interface I { void foo(A<String> a); }
class A<T> {}
