public class X {
	int portNumber;
	public static void main(String[] args) {
		X x = new X();
		x.portNumber = Integer.parseInt("12");
		x.run();
	}
	private void run() {
		System.out.println(portNumber);
	}
}