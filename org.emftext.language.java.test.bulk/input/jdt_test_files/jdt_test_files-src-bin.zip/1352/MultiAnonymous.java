public class MultiAnonymous {
	public static void main(String argv[]){
		try {
			new MultiAnonymous().performTasks(3);
		}
		catch(InterruptedException e){};
	}
	void notifyExecutionEnd() {
		System.out.println("EXECUTION FINISHED");
	}
	void notifyExecutionStart() {
		System.out.println("EXECUTION STARTING");
	}
	void performTasks(final int maxTasks) throws java.lang.InterruptedException {
		Thread workers[] = new Thread[maxTasks];
		Runnable tasks[] = new Runnable[maxTasks];
		final int maxIteration = 5;
		notifyExecutionStart();
		
		// Creating and launching the tasks
		for (int ii = 0; ii < maxTasks; ii++) {
			final int i = ii;
			tasks[i] = new Runnable() {			
				public String toString() { return ((i + 1) + " of " + maxTasks); }
				public void run() {
					for(int j = 0; j < maxIteration; j++)
						notifyCompletion( (int)((float) (j + 1) / maxIteration * 100));
				}		
			
				void notifyCompletion(int percentage) {
				}
			};
			workers[i] = new Thread(tasks[i],"Running task("+(tasks[i].toString())+")");
			workers[i].start();
		}
		// Waiting for *all* tasks to be ended
		for (int i = 0; i < tasks.length; i++)
			workers[i].join();
		notifyExecutionEnd();
	}
}
