package pack;
public class Test {
	static class Inner {
		public Object foo() { return null; }
	}
	public Inner field;
	/** 
	 * @see Inner#foo()
	 */
	public Object foo() {
		return field.foo();
	}
}
