public class X {
	public static void main(String[] s) {
		test(1);
	}
	public static void test(Integer i) { System.out.print('y'); }
}
