public class X {
    public void foo() {
        Integer i1 = 10 ;
        final short s = 100;
        i1 = s;
        switch (i1)
        {
            case s:
        }
    }
    public void bar() {
        Integer i2 = 10 ;
        final byte b = 100;
        i2 = b;
        switch (i2)
        {
            case b:
        }
    }   
    public void baz() {
        Integer i3 = 10 ;
        final char c = 100;
        i3 = c;
        switch (i3)
        {
            case c:
        }
    }     
}
