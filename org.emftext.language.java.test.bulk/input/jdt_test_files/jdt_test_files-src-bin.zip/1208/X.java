class A {
        long foo = 0L;
}

public class X {
        public static void main(String[] args) {
                A a = new A();
	             Long s = a.foo;
                System.out.println("SUCCESS");
        }
}
