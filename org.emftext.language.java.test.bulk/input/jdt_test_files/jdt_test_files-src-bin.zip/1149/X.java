public class X {

	public static void main(String[] args) {
	    Byte b = new Byte((byte)1);
	    int i = +b;
		System.out.println(i);
    }
}
