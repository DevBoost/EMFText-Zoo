public class X {
	public static void main(String[] s) {
		test(new Byte((byte) 1));
	}
	public static void test(long l) { System.out.print('y'); }
}
