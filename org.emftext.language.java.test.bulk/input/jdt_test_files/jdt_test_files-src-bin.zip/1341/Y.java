public class Y { 
	public static void main(String[] argv){ 
		if (new Y().bar() == 3) 
			System.out.println("SUCCESS"); 
		else 
			System.out.println("FAILED"); 
	} 
	int bar() { 
		final int i = "xxx".length(); 
		class X { 
			class AX { 
				int foo() { 
					return new BX().foo(); 
				} 
			} 
			class BX { 
				int foo() { 
					return new CX().foo(); 
				} 
			} 
			class CX { 
				int foo() { 
					return i; 
				} 
			} 
		} 
		return new X().new AX().foo(); 
	} 
} 
