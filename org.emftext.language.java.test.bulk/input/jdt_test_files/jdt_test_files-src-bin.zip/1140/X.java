public class X {
	public static void main(String[] args) {
		Integer i = args.length == 0 ? 0 : new Integer(1);
		System.out.println(i);
	}
}
