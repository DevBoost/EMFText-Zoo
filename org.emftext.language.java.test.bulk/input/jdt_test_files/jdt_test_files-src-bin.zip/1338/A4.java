class A4 { 
	void foo(){ 
		new A3().new B(){}; 
	} 
} 
