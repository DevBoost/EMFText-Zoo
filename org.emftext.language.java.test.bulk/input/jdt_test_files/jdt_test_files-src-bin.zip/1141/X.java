public class X {
	public static void main(String[] args) {
		Integer i = new Integer(1);
		System.out.println((int)i);
	}
}
