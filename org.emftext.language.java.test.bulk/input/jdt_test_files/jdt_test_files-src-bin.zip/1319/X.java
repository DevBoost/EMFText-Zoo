public class X implements I {}
class Y extends X {}
class Z extends Y implements J {}interface I {}
interface J {}
