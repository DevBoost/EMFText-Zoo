package test;
import test.copy.*;
public class X {
	/**
	 * Valid external classes references 
	 *
	 * @see VisibilityPublic Valid ref: visible class through import => no warning on import
	 * @see VisibilityPublic.VpPublic Valid ref: visible inner class in visible class 
	 */
	public void s_foo() {
	}
}
