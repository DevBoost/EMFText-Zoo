package pack;
import static pack.Color.*;
public class X {
    public static void main(String[] args) {
		Color c = null;
		 try {
        	c = BLACK;
		} catch(NoSuchFieldError e) {
			System.out.print("SUCCESS");
			return;
		}
      	switch(c) {
       	case BLACK:
          	System.out.print("Black");
          	break;
       	case WHITE:
          	System.out.print("White");
          	break;
      	}
    }
}