package p1;
public class Y extends X {
	/**
	 * @see #foo_package()
	 */
	protected void bar() {
		foo_package();
	}
}
