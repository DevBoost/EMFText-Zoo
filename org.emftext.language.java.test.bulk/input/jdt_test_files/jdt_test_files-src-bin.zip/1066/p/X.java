package p;
public class X {
	public enum E implements Runnable {
		SUCCESS;
		public void run(){}
	}
	public static void main(String[] args) {
		Class<E> c = E.class;
		System.out.println(c.getName() + ":" + X.E.SUCCESS);
	}
}
