class XSuper<T> {
	T value;
}
public class X extends XSuper<Integer>{
	public void a() {
		this.value--;
		--this.value;
		this.value -= 1;
		this.value = this.value - 1;
		System.out.println(this.value);
	}

	public static void main(final String[] args) {
		X x = new X();
		x.value = 5;
		x.a();
	}
}
