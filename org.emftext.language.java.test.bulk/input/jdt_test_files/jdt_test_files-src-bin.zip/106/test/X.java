package test;
public class X {
	int x;
	/**
	 * Valid local class field references
	 *
	 * @see #x Valid ref: visible field
	 * @see Visibility#vf_public Valid ref: visible field
	 * @see Visibility.VcPublic#vf_public Valid ref: visible field in visible inner class
	 */
	public void s_foo() {
	}
}
