public class X {
	public static void main(String[] s) {
		test(0.0);
	}
	public static void test(Double d) { System.out.print('y'); }
}
