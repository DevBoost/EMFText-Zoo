import java.util.ArrayList;
import java.util.List;

public class X {
	public static void main(String[] args) {
		Integer[] tab = new Integer[] {0, 1, 2, 3, 4};
	    int sum = 0;
	    for (int i : tab) {
	    	sum += i;
	    }
        System.out.print(sum);
    }
}