package test;
public class X {
	/**
	 * Valid super class field references in the same package
	 *
	 * @see Visibility#avf_public Valid ref: visible inherited field
	 * @see Visibility.AvcPublic#avf_public Valid ref: visible field of inherited visible inner class
	 */
	public void s_foo() {
	}
}
