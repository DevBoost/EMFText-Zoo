public class X {
	/**
	 * Valid URL references 
	 *
	 * @see <a href="http://java.sun.com/j2se/1.4.2/docs/tooldocs/windows/javadoc.html">Valid URL link reference</a>
	 * @see <A HREF = "http://java.sun.com/j2se/1.4.2/docs/tooldocs/windows/javadoc.html">Valid URL link reference</A>
	 * @see <a hReF = "http://java.sun.com/j2se/1.4.2/docs/tooldocs/windows/javadoc.html">Valid URL link reference</A>
	 */
	public void s_foo() {
	}
}
