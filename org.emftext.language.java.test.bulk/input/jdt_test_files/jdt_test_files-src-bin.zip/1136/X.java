public class X {
	public static void main(String[] args) {
		int[] tab = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		for (final Integer e : tab) {
			System.out.print(e);
		}
	}
}
