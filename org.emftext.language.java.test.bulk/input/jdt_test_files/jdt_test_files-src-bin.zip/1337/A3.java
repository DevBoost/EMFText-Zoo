class A3 { 
	class B {} 
} 
