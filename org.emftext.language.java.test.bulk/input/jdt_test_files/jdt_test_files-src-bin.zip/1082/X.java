public enum X implements B {

	C1 {
		public void test() {};
	},
	C2 {
		public void test() {};
	}
}

interface B {
	public void test();
	
}
