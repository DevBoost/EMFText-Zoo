package e;
import e.T;
import static e.T.*;

public class X {
    public static void main(String[] args) {
    	System.out.print("JDTCore team:");
    	T oldest = null;
    	int maxAge = Integer.MIN_VALUE;
    	for (T t : T.values()) {
            if (t == YODA) continue;// skip YODA
            t.setRole(t.isManager());
			 if (t.age() > maxAge) {
               oldest = t;
               maxAge = t.age();
            }
            System.out.print(" "+ t + ':'+t.age()+':'+location(t)+':'+t.role);
        }
        System.out.println(" WINNER is:" + T.valueOf(oldest.name()));
    }

   private enum Location { SNZ, OTT }

    private static Location location(T t) {
        switch(t) {
          case PHILIPPE:  
          case DAVID:
          case JEROME:
          case FREDERIC:
          	return Location.SNZ;
          case OLIVIER:
          case KENT:
            return Location.OTT;
          default:
            throw new AssertionError("Unknown team member: " + t);
        }
    }
}
