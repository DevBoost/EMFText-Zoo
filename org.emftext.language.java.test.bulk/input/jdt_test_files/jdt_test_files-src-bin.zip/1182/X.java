public class X
{
	public X()
	{
		super();
	}

	public Object convert(Object value)
	{
		Double d = (Double)value;
		d = (d/100);
		return d;
	}

	public static void main(String[] args)
	{
		X test = new X();
		Object value = test.convert(new Double(50));
		System.out.println(value);
	}
}
