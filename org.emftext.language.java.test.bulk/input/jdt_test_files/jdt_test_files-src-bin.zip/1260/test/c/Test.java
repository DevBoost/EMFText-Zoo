package test.c;
/**
 * @see Inner.Level2.Level3
 * @see Test.Inner.Level2.Level3
 */
public class Test {
	public class Inner {
		/**
		 * @see Level3
		 * @see Level2.Level3
		 * @see Inner.Level2.Level3
		 * @see Test.Inner.Level2.Level3
		 */
		public class Level2 {
			class Level3 {
			}
		}
	}
}
