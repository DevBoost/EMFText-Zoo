import java.lang.reflect.*;
import java.lang.annotation.*;
@ExpectedModifiers(Modifier.FINAL)
public enum EnumTest {
	X(255);
	EnumTest(int r) {}
	public static void main(String argv[]) throws Exception {
		test("EnumTest");
		test("EnumTest$EnumA");
		test("EnumTest$EnumB");
		test("EnumTest$EnumB2");
		test("EnumTest$EnumB3");
		test("EnumTest$EnumC3");
		test("EnumTest$EnumD");
	}
	static void test(String className) throws Exception {
		Class c = Class.forName(className);
		ExpectedModifiers em = (ExpectedModifiers) c.getAnnotation(ExpectedModifiers.class);
		if (em != null) {
			int classModifiers = c.getModifiers();
			int expected = em.value();
			if (expected != (classModifiers & (Modifier.ABSTRACT|Modifier.FINAL|Modifier.STATIC))) {
				if ((expected & Modifier.ABSTRACT) != (classModifiers & Modifier.ABSTRACT))
					System.out.println("FAILED ABSTRACT: " + className);
				if ((expected & Modifier.FINAL) != (classModifiers & Modifier.FINAL))
					System.out.println("FAILED FINAL: " + className);
				if ((expected & Modifier.STATIC) != (classModifiers & Modifier.STATIC))
					System.out.println("FAILED STATIC: " + className);
			}
		}
	}
	@ExpectedModifiers(Modifier.FINAL|Modifier.STATIC)
	enum EnumA {
		A;
	}
	@ExpectedModifiers(Modifier.STATIC)
	enum EnumB {
		B {
			int value() { return 1; }
		};
		int value(){ return 0; }
	}
	@ExpectedModifiers(Modifier.STATIC)
	enum EnumB2 {
		B2 {};
		int value(){ return 0; }
	}
	@ExpectedModifiers(Modifier.FINAL|Modifier.STATIC)
	enum EnumB3 {
		B3;
		int value(){ return 0; }
	}
	@ExpectedModifiers(Modifier.STATIC)
	enum EnumC implements I {
		C {
			int value() { return 1; }
		};
		int value(){ return 0; }
		public void foo(){}
	}
	@ExpectedModifiers(Modifier.STATIC)
	enum EnumC2 implements I {
		C2 {};
		int value(){ return 0; }
		public void foo(){}
	}
	@ExpectedModifiers(Modifier.FINAL|Modifier.STATIC)
	enum EnumC3 implements I {
		C3;
		int value(){ return 0; }
		public void foo(){}
	}
	@ExpectedModifiers(Modifier.ABSTRACT|Modifier.STATIC)
	enum EnumD {
		D {
			int value() { return 1; }
		};
		abstract int value();
	}
}
interface I {
	void foo();
}
@Retention(RetentionPolicy.RUNTIME)
@interface ExpectedModifiers {
	int value();
}