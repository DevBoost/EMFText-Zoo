public class X {

    interface Interface {
        public int value();
    }

    public enum MyEnum implements Interface {
        ;

        MyEnum(int value) { this.value = value; }        
        public int value() { return this.value; }

        private int value;
    }

    public static void main(String[] args) {
        System.out.println(MyEnum.values().length);
    }
}