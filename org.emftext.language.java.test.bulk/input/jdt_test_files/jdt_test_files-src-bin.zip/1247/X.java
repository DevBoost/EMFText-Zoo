public class X {
	static Boolean MyBool = null;
	static void foo() {
		if (X.MyBool) {}
	}
	public static void main(String[] args) {
		try {
			foo();
			System.out.println("FAILURE");
		} catch(NullPointerException e) {
			System.out.println("SUCCESS");
		}
	}
}