package test;
public class X {
	/**
	 * Valid package class methods references
	 * 
	 * @see Visibility#vm_public() Valid ref: visible method
	 * @see Visibility.VcPublic#vm_public() Valid ref: visible method in visible inner class
	 * @see test.Visibility#vm_public() Valid ref: visible method
	 * @see test.Visibility.VcPublic#vm_public() Valid ref: visible method in visible inner class
	 */  
	public void s_foo() {
	}
}
