public class AAA {  
	public static void main(String argv[]){  
		if (new AAA().foo(5) == 15);  
		System.out.println("SUCCESS"); 
	}  
	class B{} 
	int foo(final int loc){ 
		class I extends B { 
			int i = loc; 
			{ 
				System.out.println("loc="+ loc );	 
			} 
			int foo(){  
				System.out.println("I:i="+ i );	 
				return i;}  
		}   
		class J extends I { 
			I obj = new I(){ 
				int foo() { 
					System.out.println("J"); 
					return super.foo() + 10; }}; 
		} 
		return new J().obj.foo(); 
	} 
 }  
