class Cla<A> {
	A val;
	public Cla(A x) { val = x; }
	A getVal() { return val; }
}

public class X {
	
	void proc0(Cla<Long> b0) {
		final Long t1 = b0.getVal();
		System.out.print(t1);
		final long t2 = b0.getVal();
		System.out.print(t2);
	}

	void proc1(Cla<? extends Long> obj) {
		final Long t3 = obj.getVal();
		System.out.print(t3);
		final long t4 = obj.getVal();
		System.out.print(t4);
	}
	
	<U extends Long> void proc2(Cla<U> obj) {
		final Long t5 = obj.getVal();
		System.out.print(t5);
		final long t6 = obj.getVal();
		System.out.println(t6);
	}
	
	public static void main(String[] args) {
		X x = new X();
		x.proc0(new Cla<Long>(0l));
		x.proc1(new Cla<Long>(1l));
		x.proc2(new Cla<Long>(2l));
	}
}
