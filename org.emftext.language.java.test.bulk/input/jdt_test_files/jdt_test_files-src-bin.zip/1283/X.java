public class X {
  public static void main(String args[]) {
    final int i;
    while (true) {
      if (true) {
        break;
      } else {
        i = 0;
      }
    }
    i = 1;
    System.out.println(i);
  }
}