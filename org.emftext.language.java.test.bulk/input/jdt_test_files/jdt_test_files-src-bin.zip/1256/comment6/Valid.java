package comment6;
public class Valid {
    /**
     * @see Valid.Inner
     */
    public class Inner { }
}
/**
 * See also {@link Valid.Inner}
 */
class Sub2 extends Valid { }