public enum X { 
	
	BLEU(10),
	BLANC(20),
	ROUGE(30);

	int val;
	X(int val) {
		this.val = val;
	}

	public static void main(String[] args) {
		for(X x: values()) {
			System.out.print(x.val);
		}
	}
}
