interface TestInterface {
	int test();
}

public enum X implements TestInterface {
	TEST {
		public int test() {
			return 42;
		}
	},
	ENUM {
		public int test() {
			return 37;
		}
	};
} 
