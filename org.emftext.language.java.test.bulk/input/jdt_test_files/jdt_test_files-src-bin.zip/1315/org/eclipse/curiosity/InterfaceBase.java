package org.eclipse.curiosity;
public interface InterfaceBase {
    public void a();
    public void b();
    public void c();
    public void d();
}