package org.eclipse.curiosity;
public abstract class A implements InterfaceA {
	private void e() {
	}
	public void f() {
		this.e();
	}
}