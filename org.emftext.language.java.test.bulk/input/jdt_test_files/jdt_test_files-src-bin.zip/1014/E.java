	/**
	 * Value test: {@value #TEST}
	 * or: {@value E#TEST}
	 */
public enum E { TEST, VALID }
