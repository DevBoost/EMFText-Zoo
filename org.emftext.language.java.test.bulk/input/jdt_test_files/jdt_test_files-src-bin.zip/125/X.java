public class X {
	int x;
	public X(int i) {
		x = i;
	}
	/**
	 * @see #X(String)
	 */
	void foo() {
	}
	void X(String str) {}
}
