public class X {
	public static void main(String[] s) {
		test(Short.MAX_VALUE);
	}
	public static void test(Short s) { System.out.print('y'); }
}
