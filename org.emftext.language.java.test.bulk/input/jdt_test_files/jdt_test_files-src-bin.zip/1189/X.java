class XSuper<T> {
	T value;
}
public class X extends XSuper<Integer>{
	public void a() {
		value--;
		--value;
		value -= 1;
		value = value - 1;
		System.out.println(value);
	}

	public static void main(final String[] args) {
		X x = new X();
		x.value = 5;
		x.a();
	}
}
