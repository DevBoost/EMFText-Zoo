public class X {
	/**
	 * Valid javadoc comment with tags mixed order
	 * @param str first param
	 * 		@see String
	 * @param dbl second param
	 * 		@see Double
	 * 		also
	 * 		@see "String ref"
	 * @return int
	 * @throws InterruptedException
	 * 
	 */
	int foo(String str, Double dbl) throws InterruptedException {
		return 0;
	}
}
