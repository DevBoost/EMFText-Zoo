package p;
public class X {
  int[] x= new int[] {,};
}
