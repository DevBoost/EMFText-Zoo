public class X {
	public static void main(String[] s) {
		Byte b = 1;
		++b;
		if (b instanceof Byte) {
			System.out.println("SUCCESS");
		}
	}
}
