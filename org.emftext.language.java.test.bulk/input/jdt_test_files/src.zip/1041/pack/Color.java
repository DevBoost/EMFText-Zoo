package pack;
enum Color {WHITE, BLACK}