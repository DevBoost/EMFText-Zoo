public class X {
	Boolean[] myBool = new Boolean[1];
	void foo() {
		if (this.myBool[0]) {}
	}
	public static void main(String[] args) {
		try {
			new X().foo();
			System.out.println("FAILURE");
		} catch(NullPointerException e) {
			System.out.println("SUCCESS");
		}
	}
}