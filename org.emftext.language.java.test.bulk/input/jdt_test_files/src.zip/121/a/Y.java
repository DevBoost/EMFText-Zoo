package a;

/** */
public class Y {
	protected boolean bar(Object obj) {
		return obj == null;
	}
}
