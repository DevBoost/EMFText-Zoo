package test;

import a.Y;

/** */
public class YY extends Y {
	/**
	 * Returns a Boolean.
	 * @param key
	 * @return A Boolean telling whether the key is null or not.
	 * @see #bar(Object)
	 */
	protected Boolean foo(Object key) {
		return X.valueOf(bar(key));
	}
}
