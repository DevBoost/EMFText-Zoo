class A<T> {
        public T foo() { return null; }
}

public class X {
        public static void main(String[] args) {
                A<Long> a = new A<Long>();
				 A ua = a;
                try {
	                long s = a.foo();
                } catch(NullPointerException e) {
                	System.out.println("SUCCESS");
                	return;
                }
            	System.out.println("FAILED");
        }
}
