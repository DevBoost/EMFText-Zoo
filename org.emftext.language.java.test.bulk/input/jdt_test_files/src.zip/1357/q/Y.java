package q; 
public class Y { 
	protected Object someObject; 
}
