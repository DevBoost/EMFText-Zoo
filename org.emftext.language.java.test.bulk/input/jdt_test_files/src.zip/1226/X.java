public class X {
	static void print(Character c) {
		System.out.print((char) c);
	}
	public static void main(String[] args) {
		char c = 'H';
		print(++c);
		print(++c);
		System.out.println("done");
    }
}
