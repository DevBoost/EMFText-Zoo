  public class X {
    enum NoValues {}
    public static void main(String[] args) {
      System.out.println("["+NoValues.values().length+"]");
    }
  }
