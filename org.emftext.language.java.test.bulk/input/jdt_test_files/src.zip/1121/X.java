public class X {
	public static void main(String[] s) {
		test(new Double(0.0));
	}
	public static void test(double d) { System.out.print('y'); }
}
