	/**
	 * @see "Valid normal string"
	 * @see <a href="http://java.sun.com/j2se/1.4.2/docs/tooldocs/windows/javadoc.html">Valid URL link reference</a>
	 * @see Object
	 * @see #TEST
	 * @see E
	 * @see E#TEST
	 */
public enum E { TEST, VALID }
