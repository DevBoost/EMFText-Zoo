public class X {
	public static class Y {
		public static Byte b = new Byte((byte)1);
	}
	public static void main(String[] s) {
		X.Y.b++;
		if (X.Y.b instanceof Byte) {
			System.out.print("SUCCESS" + X.Y.b);
		}
	}
}
