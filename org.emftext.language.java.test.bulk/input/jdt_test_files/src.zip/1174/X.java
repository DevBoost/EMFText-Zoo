public class X {
	public static void main(String[] args) {
		Boolean bool = true;
		assert bool : "failed";
	    System.out.println("SUCCESS");
	}
}
