public class MultiComplex {
	// should just be an interface, once supported...
	abstract class AbstractTask implements Runnable {
		public void run() {
			MultiComplex.this.notifyCompletion(this,0); 
		}
		abstract public String taskName();		
	}
	public static void main(String argv[]){
		try {
			new MultiComplex().performTasks(3);
		}
		catch(InterruptedException e){};
	}  
	void notifyCompleted(AbstractTask task) {
	}
	void notifyCompletion(AbstractTask task, int percentage) {
	}
	void notifyExecutionEnd() {
		System.out.println("EXECUTION FINISHED");
	}
	void notifyExecutionStart() {
		System.out.println("EXECUTION STARTING");
	}
	void performTasks(final int maxTasks) throws InterruptedException {
		Thread workers[] = new Thread[maxTasks];
		AbstractTask tasks[] = new AbstractTask[maxTasks];
		final int maxIteration = 5;
 
		// Local Task 
		class Task extends AbstractTask { 
				String taskName; 
				Task(String aName) {
					taskName = aName;
				}
				public String taskName() { 
					return taskName; 
				}
	
				public void run() {
					super.run();
					for(int j = 0; j < maxIteration; j++)
						MultiComplex.this.notifyCompletion(this,  (int)((float) (j + 1) / maxIteration * 100));
				}
		};
		notifyExecutionStart();
		
		// Creating and launching the tasks
		for (int ii = 0; ii < maxTasks; ii++) {
			final int i = ii;
			tasks[i] = new Task(String.valueOf(i + 1)) {			
				public String taskName() { 
					return super.taskName() +  " of " + maxTasks; }
				public void run() {
					super.run();
					MultiComplex.this.notifyCompleted(this);
				}		
			};
			workers[i] = new Thread(tasks[i],tasks[i].taskName());
			workers[i].start();
		}
		// Waiting for *all* tasks to be ended
		for (int i = 0; i < tasks.length; i++)
			workers[i].join();
		notifyExecutionEnd();
	}
}
