public enum X1 implements I {
	;
}
interface I {}
