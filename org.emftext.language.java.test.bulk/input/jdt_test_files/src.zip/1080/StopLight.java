public enum StopLight{
    RED{
        public StopLight next(){ return GREEN; }
    },
    GREEN{
        public StopLight next(){ return YELLOW; }
    },
    YELLOW{
        public StopLight next(){ return RED; }
    };

   public abstract StopLight next();
}