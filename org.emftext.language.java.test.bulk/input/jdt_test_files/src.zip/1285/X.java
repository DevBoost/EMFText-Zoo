public class X {
  public static void main(String args[]) {
    final int i;
    for (; 0 < (i = 1);) {
      break;
    }
    System.out.println("SUCCESS");
  }
}