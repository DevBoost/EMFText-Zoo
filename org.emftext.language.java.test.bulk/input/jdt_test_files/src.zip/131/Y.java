import java.io.IOException;
public class Y extends X {
	/**
	 * @throws IOException
	 * @see X#foo()
	 */
	public void foo() throws IOException {}
}
