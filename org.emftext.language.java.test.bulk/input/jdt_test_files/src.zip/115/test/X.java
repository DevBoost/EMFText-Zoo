package test;
public class X {
	/**
	 * Valid package super class methods references
	 * 
	 * @see Visibility#avm_public() Valid ref: visible inherited method
	 * @see Visibility.AvcPublic#avm_public() Valid ref: visible inherited method in visible inner class
	 * @see test.Visibility#avm_public() Valid ref: visible inherited method
	 * @see test.Visibility.AvcPublic#avm_public() Valid ref: visible inherited method in visible inner class
	 */  
	public void s_foo() {
	}
}
