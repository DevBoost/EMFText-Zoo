public class X {
	
	public static void main(String[] args) {
		E.A.bar();
	}
}
enum E {
	A {
		void bar() {
			new X(){
				void baz() {
					new M();
				}
			}.baz();
		}
	};
	abstract void bar();
	
	class M {
		M() {
			System.out.println("SUCCESS");
		}
	}
}
