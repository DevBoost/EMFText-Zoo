public class X {
	public static void main(String[] s) {
		Integer i = new Integer(1);
		switch(i) {
			case 1 : System.out.print('y');
		}
	}
}
