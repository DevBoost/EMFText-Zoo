public class X { 
	public static void main(String[] argv){ 
		new B(); 
		System.out.println("SUCCESS"); 
	} 
	private static void foo(int i, int j) { 
		System.out.println("private foo"); 
	} 
	static class B { 
		{ 
			foo(1, 2); 
		} 
	} 
}		 
