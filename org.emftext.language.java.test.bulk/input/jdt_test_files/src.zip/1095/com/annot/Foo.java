package com.annot;

import static com.annot.TestType.*;

public class Foo {
	@Test(type=PERFORMANCE)
	public void testBar() throws Exception {
		Test annotation = this.getClass().getMethod("testBar").getAnnotation(Test.class);
		switch (annotation.type()) {
			case PERFORMANCE:
				System.out.println(PERFORMANCE);
				break;
			case CORRECTNESS:
				System.out.println(CORRECTNESS);
				break;
		}		
	}
}