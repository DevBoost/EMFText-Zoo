package com.annot;

public enum TestType {
	CORRECTNESS,
	PERFORMANCE
}