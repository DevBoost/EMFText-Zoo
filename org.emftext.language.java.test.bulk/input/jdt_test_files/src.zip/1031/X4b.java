public enum X4b {
	A() { public void test() {} };
	public abstract void test();
}
