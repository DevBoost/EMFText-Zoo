public class X {
    public static void main(String args[]) {
    	if (new Boolean(true) ? true : new Boolean(false)) {
    		System.out.print("SUCCESS");
    	} else {
    		System.out.print("FAILED");
    	}
    }
}
