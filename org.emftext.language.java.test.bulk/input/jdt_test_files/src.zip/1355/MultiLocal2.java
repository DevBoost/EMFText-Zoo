public class MultiLocal2 {
	public static void main(String argv[]){
		final int maxTasks = 3;
		class Task implements Runnable {
			private String taskName;
			private int maxIteration;
			public Task(String name, int value) {
				taskName = name; 
				maxIteration = value;
			}
	
			public String toString() { return taskName + " of " + String.valueOf(maxTasks); }
			public void run() {
				for(int i = 0; i < maxIteration; i++)
					notifyCompletion( (int)((float) (i + 1) / maxIteration * 100));
			}		
			
			void notifyCompletion(int percentage) {
			}
		};
		MultiLocal2 multi = new MultiLocal2();
		Task tasks[] = new Task[maxTasks];
		for (int i = 0; i < maxTasks; i++) 
			tasks[i] = new Task(String.valueOf(i+1),5);
		try {
			multi.performTasks(tasks);
		}
		catch(InterruptedException e){};
	}
	void notifyExecutionEnd() {
		System.out.println("EXECUTION FINISHED");
	}
	void notifyExecutionStart() {
		System.out.println("EXECUTION STARTING");
	}
	void performTasks(Runnable tasks[]) throws java.lang.InterruptedException {
		Thread workers[] = new Thread[tasks.length];
		notifyExecutionStart();
		
		// Launching the tasks
		for (int i = 0; i < tasks.length; i++) {
			workers[i] = new Thread(tasks[i],"Running task("+(tasks[i].toString())+")");
			workers[i].start();
		}
		// Waiting for *all* tasks to be ended
		for (int i = 0; i < tasks.length; i++)
			workers[i].join();
		notifyExecutionEnd();
	}
}
