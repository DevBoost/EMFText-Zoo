public class A { 
	public static void main(String[] argv){ 
		if (new A().foo() == 5) 
			System.out.println("SUCCESS"); 
		else 
			System.out.println("FAILED"); 
	} 
	int foo() { 
		return new A() { 
			int foo() { 
				final int i = "hello".length(); 
				return new A() { 
					int foo() { 
						return i; 
					} 
				} 
				.foo(); 
			} 
		} 
		.foo(); 
	} 
} 
