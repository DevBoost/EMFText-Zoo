public enum X2c implements I {
	A() { void random() {} };
	public void test() {}
}
interface I { void test(); }
