public class X {
	public static void main(String[] args) {
		int foo = 0;
		String bar = "zero";
		System.out.println((foo != 0) ? foo : bar);
	}
}
