public enum X {
	A () { public void foo() {} }
	;
	
	public abstract void foo();
}
