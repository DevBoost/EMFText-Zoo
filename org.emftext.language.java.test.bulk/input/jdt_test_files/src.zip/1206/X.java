class A<T> {
        public T foo;
}

public class X extends A<Long>{
        public static void main(String[] args) {
			new X().foo();
		 }
 		 public void foo() {
				 A ua = this;
				 ua.foo = new Object();
                try {
	                long s = foo;
                } catch(ClassCastException e) {
                	System.out.println("SUCCESS");
                	return;
                }
            	System.out.println("FAILED");
        }
}
