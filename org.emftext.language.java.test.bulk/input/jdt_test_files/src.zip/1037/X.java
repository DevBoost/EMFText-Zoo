public class X {

	enum Test1 {
		V;
		void foo() {}
	}
	class Member<E extends Test1> {
		void bar(E e) {
			e.foo();
		}
	}
}
