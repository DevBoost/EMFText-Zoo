public enum TestEnum {
	RED, GREEN, BLUE; 
    static int test = 0;  
}

enum TestEnum2 {
	; 
    TestEnum2() {
        TestEnum.test=12;
    }
}
