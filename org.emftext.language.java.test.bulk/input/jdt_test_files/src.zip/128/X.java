/** */
public class X {
  /** */
  public void foo(){
    new Object(){
		public int x;
       public void bar(){}
    };
  }
}
