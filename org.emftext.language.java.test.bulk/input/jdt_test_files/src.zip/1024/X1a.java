public enum X1a implements I {
	A;
}
interface I {}
