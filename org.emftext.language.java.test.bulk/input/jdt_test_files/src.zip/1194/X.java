public class X {
	public static void main(String[] s) {
		char c = 'a';
		System.out.printf("%c",c);		
		System.out.printf("%d\n",(int)c);		
	}
}
