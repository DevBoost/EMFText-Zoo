package p1;								
import p2.*;								
public class A {							
	protected int value = 0;				
	protected A delegatee;					
	public A(A del, int val) {				
		this.delegatee = del;				
		this.value = val;					
	}										
	protected void foo() {					
		value += 3;							
	}										
	public static void main(String[] argv){	
		int result = new B(					
					  new B(null, 10), 20)  
					 .value; 				
		int expected = 30; 					
		System.out.println( 				
			result == expected 				
				? "SUCCESS"  				
				: "FAILED : got "+result+" instead of "+ expected); 
	}										
}											
