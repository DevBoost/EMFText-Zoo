package p2;								
import p1.*;								
public class B extends A {					
	public B(B del, int val){				
		super(del, val);					
		Runnable r = new Runnable () {		
			public void run() {				
				foo(); 						
				if (delegatee != null) 		
					value += 7;				
			}								
		};									
		r.run();							
	}										
}											
