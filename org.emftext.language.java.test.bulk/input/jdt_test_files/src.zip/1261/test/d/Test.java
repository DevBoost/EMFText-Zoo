package test.d;
/**
 * @see Secondary
 * @see Reference
 */
public class Test {
}
class Secondary {}