public class X {
	public static void main(String[] args) {
		int a = 1;
	    a = a++;
		System.out.print("a="+a);
		
		int b = 1;
		System.out.print(b = b++);
		System.out.println("b="+b);
	}
}
