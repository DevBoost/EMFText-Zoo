package test;
public class Test {
	static class Inner1 {
		public Object foo() { return null; }
	}
	static class Inner2 {
		public Inner1 field;
		/** 
		 * @see Inner1#foo()
		 */
		public Object foo() {
			return field.foo();
		}
	}
}
