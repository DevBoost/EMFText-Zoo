public class Y2 {
	/** */
	void foo() {
		X x = new X() {
			/**
			 * Valid javadoc comment in anonymous class.
			 * @param str String
			 * @return int
			 */
			int bar(String str) {
				return 10;
			}
		};
		x.foo(0, "");
	}
}
