public class Y3 {
	static X x;
	static {
		x = new X() {
			/**
			 * Valid javadoc comment in anonymous class.
			 * @param str String
			 * @return int
			 */
			int bar(String str) {
				return 10;
			}
		};
	}
}
