public class X {
	public static void main(String[] args) {
		Integer someInteger = 12;
		System.out.println((args == null ? someInteger : 'A') == 'A');
	}
}
