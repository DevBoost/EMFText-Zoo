public class Y2 {
	/** */
	void foo() {
		X x = new X() {
			/** Invalid javadoc comment in anonymous class */
			void foo(String str) {}
		};
		x.foo(0, "");
	}
}
