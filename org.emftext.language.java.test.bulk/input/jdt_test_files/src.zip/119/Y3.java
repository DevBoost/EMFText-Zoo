public class Y3 {
	static X x;
	static {
		x = new X() {
			/** Invalid javadoc comment in anonymous class */
			void foo(String str) {}
		};
	}
}
