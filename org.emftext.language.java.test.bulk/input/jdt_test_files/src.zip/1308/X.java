public class X {
	public static void main(String[] args) {
		int result;
		if (130 != (result = testShort1())) System.out.println("failed-testShort1():" + result);
		if (130 != (result = testShort2())) System.out.println("failed-testShort2():" + result);
		if (130 != (result = testInt1())) System.out.println("failed-testInt1():" + result);
		if (130 != (result = testInt2())) System.out.println("failed-testInt2():" + result);
		if (30 != (result = testByte1())) System.out.println("failed-testByte1():" + result);
		if (30 != (result = testByte2())) System.out.println("failed-testByte2():" + result);
		System.out.println("done");
	}
	static int testShort1() {
		short min = Short.MIN_VALUE;
		int num = -32638;
		return num = num - min;
	}
	static int testShort2() {
		final short min = Short.MIN_VALUE;
		int num = -32638;
		return num = num - min;
	}
	static int testInt1() {
		short min = Short.MIN_VALUE;
		int num = -32638;
		return num = num - min;
	}
	static int testInt2() {
		final short min = Short.MIN_VALUE;
		int num = -32638;
		return num = num - min;
	}	
	static int testByte1() {
		byte min = Byte.MIN_VALUE;
		int num = -98;
		return num = num - min;
	}
	static int testByte2() {
		final byte min = Byte.MIN_VALUE;
		int num = -98;
		return num = num - min;
	}		
}
