public class X {
	public static void main(String[] args) {
		Integer x = new Integer(15); 
		int y = 32;
		System.out.printf("%x + %x", x, y);
	}
}