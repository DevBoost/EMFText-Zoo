public enum X {
    PLUS {
        double eval(double x, double y) { return x + y; }
    };

    // Perform the arithmetic X represented by this constant
    abstract double eval(double x, double y);
}