public class X {
	public static void main(String[] args) {
		foo1();
		foo2();
		foo3();
		System.out.println("[done]");
	}
	static void foo1() {
		Object x = true ? 3.0f : false;
		System.out.print("[1:"+ x + "," + x.getClass().getCanonicalName() + "]");
	}
	static void foo2() {
		Object x = true ? 2 : false;
		System.out.print("[2:"+ x + "," + x.getClass().getCanonicalName() + "]");
	}
	static void foo3() {
		Object x = false ? 2 : false;
		System.out.print("[3:"+ x + "," + x.getClass().getCanonicalName() + "]");
	}
}
