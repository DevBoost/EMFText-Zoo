public enum X {
  a(1);
  X(int i) {
  }
}