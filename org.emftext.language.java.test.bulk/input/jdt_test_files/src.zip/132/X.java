import java.io.*;

public class X {
	/**
	 * @throws IOException
	 * @throws EOFException
	 * @throws FileNotFoundException
	 */
	public void foo() throws IOException {}
}
