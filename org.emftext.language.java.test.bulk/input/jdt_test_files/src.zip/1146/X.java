public class X {
	public static void main(String[] args) { test(2); }
	static void test(Object o) { System.out.println('y'); }
}
