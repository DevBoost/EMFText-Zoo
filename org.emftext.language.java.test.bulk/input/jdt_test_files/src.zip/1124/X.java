public class X {
	public static void main(String[] s) {
		test(Boolean.TRUE);
	}
	public static void test(boolean b) { System.out.print('y'); }
}
