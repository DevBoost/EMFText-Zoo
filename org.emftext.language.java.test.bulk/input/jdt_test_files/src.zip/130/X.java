/** */
public class X extends RuntimeException {
	
	/**
	 * @see RuntimeException#RuntimeException(java.lang.String)
	 */
	public X(String message) {
		super(message);
	}
}
