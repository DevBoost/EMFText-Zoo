package p;
public class B {
  public static void main(String[] args) {
    int offset = -8;
    int temp = 0 - offset;
    offset = 0 - offset;  // This is the problem line
    System.out.println("offset: " + offset);
    System.out.println("temp: " + temp);
    if (offset != temp ) {
      System.err.println("offset (" + offset + ") should be equal to temp (" + temp + ").");
      System.exit(-1);
    }
  }
}
