enum Week {
	Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
}
public class X {
	public static void main(String[] args) {
		new X().foo();
		new X().bar();		
	}
	void foo() {
		for (Week w : Week.values())
			System.out.print(w + " ");
	}
	void bar() {
		for (Week w : java.util.EnumSet.range(Week.Monday, Week.Friday)) {
			System.out.print(w + " ");
		}
	}
}
