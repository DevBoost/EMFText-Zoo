package pack;
import static pack.Color.*;
public class X {
	public int[] $SWITCH_TABLE$pack$Color;
	public int[] $SWITCH_TABLE$pack$Color() { return null; }
   public static void main(String[] args) {
        Color c = BLACK;
        switch(c) {
        case BLACK:
            System.out.print("Black");
            break;
        case WHITE:
            System.out.print("White");
            break;
        }
    }
}