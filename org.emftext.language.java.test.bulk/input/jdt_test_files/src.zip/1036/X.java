public class X {
	enum Test1 {
		V;
		interface Foo {}
	}
}
