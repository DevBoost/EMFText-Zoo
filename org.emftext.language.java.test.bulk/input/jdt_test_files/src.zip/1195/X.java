public class X {
    public static <T extends Integer> void foo(final T[] p) {
        System.out.println(p[0] / 4);
    }
    public static void main(final String[] args) {
        X.foo(new Integer[] { 4, 8, 16 });
    }
}