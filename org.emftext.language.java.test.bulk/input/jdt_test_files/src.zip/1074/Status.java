import java.util.HashMap;
import java.util.Map;

enum Status {
	GOOD((byte) 0x00), BAD((byte) 0x02);
	private byte value;
	private static Map<Byte, Status> mapping;
	private Status(final byte newValue) {
		this.value = newValue;
	}
	static {
		Status.mapping = new HashMap<Byte, Status>();
		for (Status s : values()) {
			Status.mapping.put(s.value, s);
		}
	}
}
