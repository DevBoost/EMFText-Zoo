public class X {
	public static void main(String[] s) {
		test(new Integer(1));
	}
	public static void test(int i) { System.out.print('y'); }
}
