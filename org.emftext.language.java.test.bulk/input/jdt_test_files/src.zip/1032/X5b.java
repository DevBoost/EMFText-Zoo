public enum X5b implements I {
	A() { public void test() {} };
	;
}
interface I { void test(); }
