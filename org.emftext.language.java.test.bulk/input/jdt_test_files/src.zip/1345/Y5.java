public class Y5 { 
	public static void main(String[] argv){ 
		if (new Y5().bar(5) == 5) 
			System.out.println("SUCCESS"); 
		else 
			System.out.println("FAILED"); 
	} 
	int bar(final int i) { 
		class X { 
			int bar() { 
				return new Object(){  
						int foo(){ 
							return i; 
						} 
					}.foo(); 
			} 
		} 
		return new X().bar(); 
	} 
} 
