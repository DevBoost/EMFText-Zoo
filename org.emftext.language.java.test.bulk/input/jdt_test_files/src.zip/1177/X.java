public class X {
 Object e() {
  return "".compareTo("") > 0;
 }
 public static void main(String[] args) {
  System.out.print(new X().e());
 }
}