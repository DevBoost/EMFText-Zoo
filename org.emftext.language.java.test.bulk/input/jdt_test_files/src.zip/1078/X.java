public enum X
{
  FIRST,
  SECOND,
  THIRD;

  static {
    for (X t : values()) {
      System.out.print(t.name());
    }
  }

  X() {
  }

  public static void main(String[] args) {
  }
}