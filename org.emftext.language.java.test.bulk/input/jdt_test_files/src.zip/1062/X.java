public enum X {
	PLUS {/*ANONYMOUS*/}, MINUS;
	void bar(X x) {
		Runnable r = (Runnable)x;
	}
}