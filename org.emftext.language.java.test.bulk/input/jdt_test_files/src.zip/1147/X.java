public class X {
	public static void main(String[] args) { test(true); }
	static void test(Object ... o) { System.out.println('y'); }
}
