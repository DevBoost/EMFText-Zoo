public class X {

	public static void main(String[] args) {
		Integer i = new Integer(1);
		if (i == null)
			i++;
		System.out.print(i);
	}
}