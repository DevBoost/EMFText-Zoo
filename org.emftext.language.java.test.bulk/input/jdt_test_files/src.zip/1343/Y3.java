public class Y3 { 
	public static void main(String[] argv){ 
		if (new Y3().bar() == 8) 
			System.out.println("SUCCESS"); 
		else 
			System.out.println("FAILED"); 
	} 
	int bar() { 
		final int i = "xxx".length(); 
		final String s = this.toString(); 
		class X { 
			class AX { 
				int foo() { 
					return i + new CX().foo(); 
				} 
			} 
			class BX { 
				int foo() { 
					return new AX().foo(); 
				} 
			} 
			class CX { 
				int foo() { 
					return 5; 
				} 
			} 
		} 
		return new X().new AX().foo(); 
	} 
} 
