class A<T> {
        public T foo;
}

public class X {
        public static void main(String[] args) {
                A<Long> a = new A<Long>();
				 A ua = a;
				 ua.foo = new Object();
                try {
	                long s = a.foo;
                } catch(ClassCastException e) {
                	System.out.println("SUCCESS");
                	return;
                }
            	System.out.println("FAILED");
        }
}
