public class X<T> {
    T m;
    X(T p) {
        this.m = p;
    }
    public static void main(String[] args) {
        X<Integer> l = new X<Integer>(0);
        l.m++;
        System.out.println(l.m);
    }
}