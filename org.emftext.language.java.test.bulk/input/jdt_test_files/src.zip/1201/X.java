public class X {
	static Boolean myBool = null;
	static void foo() {
		if (myBool) {}
	}
	public static void main(String[] args) {
		try {
			foo();
			System.out.println("FAILURE");
		} catch(NullPointerException e) {
			System.out.println("SUCCESS");
		}
	}
}