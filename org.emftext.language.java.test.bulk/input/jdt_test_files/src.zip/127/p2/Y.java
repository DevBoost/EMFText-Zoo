package p2;
import p1.X;

public class Y extends X {
	/**
	 * @see X#foo_protected()
	 */
	protected void bar() {
		foo_protected();
	}
}
