package p1;
public class X {
	void foo_package() {}
	protected void foo_protected() {}
}
