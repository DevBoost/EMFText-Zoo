public class X {
	enum Couleur { 
		BLEU, BLANC, ROUGE; // take precedence over toplevel BLEU type
	}
	class Y implements IX, JX {
		void foo(Couleur c) {
			switch (c) {
				case BLEU :
					break;
				case BLANC :
					break;
				case ROUGE :
					break;
			}
		}	
	}
}

interface IX {
	int BLEU = 1;
}
interface JX {
	int BLEU = 2;
}
class BLEU {}

