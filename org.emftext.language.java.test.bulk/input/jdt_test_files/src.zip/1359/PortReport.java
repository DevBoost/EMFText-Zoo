import java.util.*; 
public class PortReport { 
	public static void main(String[] args) { 
		Portfolio port = new Portfolio("foobar"); 
		System.out.println("SUCCESS"); 
	} 
} 
