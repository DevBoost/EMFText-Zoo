public class X {
	public static void main(String[] args) {
		if(new Double(2.0) == 0.0) {}
		System.out.println("SUCCESS");
	}
}