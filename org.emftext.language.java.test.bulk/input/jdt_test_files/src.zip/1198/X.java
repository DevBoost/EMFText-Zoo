public class X {
        public static void main(String[] s) {
                Object[] os1 = new Object[] {(long)1234567};
                Object[] os2 = new Object[] {1234567};
                Object o1 = os1[0], o2 = os2[0];
                if (o1.getClass().equals(o2.getClass())) {
                    System.out.println("FAILED:o1["+o1.getClass().getName()+"],o2:["+o2.getClass()+"]");
                } else {
                    System.out.println("SUCCESS:o1["+o1.getClass().getName()+"],o2:["+o2.getClass()+"]");
                }
        }
}
