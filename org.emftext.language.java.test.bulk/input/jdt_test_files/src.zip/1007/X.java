public enum X {
	SUC, CESS;
	public static void main(String[] args) {
		for (X x : values()) {
			System.out.print(x.name());
		}
	}
}