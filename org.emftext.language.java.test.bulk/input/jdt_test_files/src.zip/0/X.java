class X {
  void foo() {
    class Local {
      class Member1 {
        void bar() {
          Member2 m2; // Member2 is deprecated
        }
      }
      @Deprecated
      class Member2 {
      }
    }
  }
}
