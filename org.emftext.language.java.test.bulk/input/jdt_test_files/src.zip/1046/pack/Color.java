package pack;
enum Color { BLACK }