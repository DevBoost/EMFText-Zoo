public class A {
    public static void main(String[] args) {
        float[] tab = new float[] {0.0f};
        System.out.print(tab[0]);
    }
}