package p;

public class Placeholder {
    public static void main(String... argv) {
        ClassWithBadEnum.EnumClass constant = ClassWithBadEnum.EnumClass.ENUM1;
        ClassWithBadEnum.main(argv);
	}
}    

