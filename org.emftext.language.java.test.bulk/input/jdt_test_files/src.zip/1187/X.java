import java.util.HashMap;

public class X {
	public static void main(String[] args) {
		try {
			String x = "";
			HashMap<String, Integer> y = new HashMap<String, Integer>();
			Integer w = (x.equals("X") ? 0 : y.get("yKey"));
		} catch(NullPointerException e) {
			System.out.println("SUCCESS");
		}
	}
}
