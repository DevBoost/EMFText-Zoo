public enum X {
    SUCCESS (0) {};
    private X(int i) {}
    public static void main(String[] args) {
       for (X x : values()) {
           System.out.print(x);
       }
    }
}