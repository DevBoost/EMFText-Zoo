import static test.E.TEST;
	/**
	 * @see test.E
	 * @see test.E#VALID
	 * @see #TEST
	 */
public class X {}
