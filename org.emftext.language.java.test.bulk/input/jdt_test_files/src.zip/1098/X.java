public enum X {
        A, B, C;
}
