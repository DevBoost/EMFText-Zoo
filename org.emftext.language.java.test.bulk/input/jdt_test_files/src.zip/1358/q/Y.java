package q; 
public class Y { 
	protected Object foo(){ return null;} 
}
