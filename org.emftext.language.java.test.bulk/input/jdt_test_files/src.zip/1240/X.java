public class X {
	public static void main(String argv[]) {
		System.out.println(void.class == Void.TYPE);
	}
}