public class X {
	static X singleton = new X();
	static X singleton() { return singleton; }
	char c = 'H';
	
	static void print(Character c) {
		System.out.print((char) c);
	}
	public static void main(String[] args) {
		print(singleton().c++);
		print(singleton().c++);
		System.out.println("done");
    }
}
