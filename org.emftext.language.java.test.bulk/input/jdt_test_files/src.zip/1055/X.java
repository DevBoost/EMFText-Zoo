public class X {
   public static void main(String[] args) {
      for(Action a : Action.values()) {
         switch(a) {
         case ONE:
            System.out.print("1");
            break;
         case TWO:
            System.out.print("2");
            break;
         default:
            System.out.print("default");
         }
      }
   }
}