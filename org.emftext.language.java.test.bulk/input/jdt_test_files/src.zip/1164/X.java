public class X {
	public static void main(String[] s) {
		byte[] bytes = {0, 1, 2};
		for(Byte b : bytes) {
			System.out.print(b);
		}
	}
}
