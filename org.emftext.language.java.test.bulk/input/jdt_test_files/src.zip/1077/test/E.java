package test;
public enum E { TEST, VALID }
