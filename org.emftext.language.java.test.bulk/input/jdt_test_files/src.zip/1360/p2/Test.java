package p2;	
public class Test {	
	public static void main (String args[]){	
		new c2();	
	}	
}	
