package p1;	
public class c1 {	
	protected class c1a{	
		public c1a(){}	
		public void foo(){ System.out.println("Foo called");	
		}	
	};	
}	
