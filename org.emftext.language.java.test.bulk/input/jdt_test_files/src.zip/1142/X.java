public class X {

	public static void main(String[] args) {
	    Byte b = new Byte((byte)1);
      System.out.println(2 + b);
    }
}
