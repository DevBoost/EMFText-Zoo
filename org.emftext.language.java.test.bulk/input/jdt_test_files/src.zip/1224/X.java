public class X<T> {
        T counter;
        public static void main(String[] args) {
        	 bar(new X<Integer>());
        	 new Y().foo();
        	 new Y().baz();
        }
        static void bar(X<Integer> x) {
        	x.counter = 0;
            System.out.print(Integer.toString(++x.counter));
        }
}

class Y extends X<Integer> {
	Y() {
		this.counter = 0;
	}
    void foo() {
        System.out.print(Integer.toString(++counter));
    }
    void baz() {
        System.out.println(Integer.toString(++this.counter));
    }
}
