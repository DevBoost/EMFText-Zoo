public class Z1 { 
	public static void main(String[] argv){ 
		new Z1().new W(); 
		System.out.println("SUCCESS"); 
	} 
	class W extends Y { 
		W() { 
			super(new Object(), foo()); 
		} 
	} 
	String foo() { 
		return ""; 
	} 
} 
class Y { 
	Y(Object o, String s) { 
	} 
}	
