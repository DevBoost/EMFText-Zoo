public class X {
   public static void main(String[] s) {
      System.out.print(Boolean.TRUE || Boolean.FALSE);
   }
}