public class X {
	public static void main(String[] s) {
		test(false);
	}
	public static void test(Boolean b) { System.out.print('y'); }
}
