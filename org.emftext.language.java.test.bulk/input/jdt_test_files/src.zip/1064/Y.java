import p.X;
public class Y {
	public static void main(String[] args) {
		System.out.println(X.E.SUCCESS);
	}
}
