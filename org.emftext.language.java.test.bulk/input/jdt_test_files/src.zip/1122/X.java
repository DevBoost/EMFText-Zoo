public class X {
	public static void main(String[] s) {
		test(new Long(0L));
	}
	public static void test(long l) { System.out.print('y'); }
}
