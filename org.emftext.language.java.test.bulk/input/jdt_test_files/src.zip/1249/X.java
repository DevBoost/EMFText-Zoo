public class X {
	public static void main(String[] args) {
		Z test = new Z(1, 1);
		System.out.println("SUCCESS");
	}
}