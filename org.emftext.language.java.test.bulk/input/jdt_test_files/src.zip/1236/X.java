import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

public class X {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < 5; i++) {
			list.add(i);
	    }
	    int sum = 0;
	    for (Iterator<Integer> iterator = list.iterator(); iterator.hasNext(); ) {
	    	if (1 == iterator.next()) {
	    		System.out.println("SUCCESS");
	    		break;
	    	}
	    }
    }
}
