public class X {

	enum Test1 {
		V;
		void foo() {}
	}
	class Member<E extends Test1> {
		E e;
		void bar(Member<? extends Test1> me) {
		}
	}
}
