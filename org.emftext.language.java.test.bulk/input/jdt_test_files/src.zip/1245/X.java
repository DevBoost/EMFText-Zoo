public class X {
	public static void main(String[] args) {
		Short s;
		s = 5;  // Type mismatch: cannot convert from int to Short
		Short[] shorts = { 0, 1, 2, 3 };
		System.out.println(s+shorts[2]);
	}
}
