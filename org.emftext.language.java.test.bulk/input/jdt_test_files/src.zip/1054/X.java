public enum X {
	VALUE {
		void foo() {
		};
	};
	abstract void foo();
    public static void main(String[] args) {
      System.out.println("["+X.values().length+"]");
    }
}