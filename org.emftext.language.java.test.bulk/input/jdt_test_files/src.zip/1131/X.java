public class X {
	public static void main(String[] s) {
		int i = Y.test();
		System.out.print(i);
	}
}
class Y {
	public static Byte test() { return new Byte((byte) 1); }
}
