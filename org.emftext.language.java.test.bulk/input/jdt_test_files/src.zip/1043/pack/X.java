package pack;
import static pack.Color.*;
public class X {
    public static void main(String[] args) {
        Color c = BLACK;
        switch(c) {
        }
		 System.out.print("SUCCESS");
    }
}