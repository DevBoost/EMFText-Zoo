public class X {
	public static void main(String[] s) {
		test(new Short((short) 0));
	}
	public static void test(short s) { System.out.print('y'); }
}
