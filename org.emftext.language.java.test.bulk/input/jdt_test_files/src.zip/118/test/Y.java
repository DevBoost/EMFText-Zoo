package test;
class Y {
  /** */
  protected X field = new X() {
    void foo(int x, String str) {}
  };
}
