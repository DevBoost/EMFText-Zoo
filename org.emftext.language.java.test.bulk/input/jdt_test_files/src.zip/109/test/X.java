package test;
public class X {
	/**
	 * Invalid other package non visible class fields references
	 *
	 * @see test.copy.VisibilityPublic#vf_public Valid ref to not visible field of other package class
	 * @see test.copy.VisibilityPublic.VpPublic#vf_public Valid ref to not visible field of other package public inner class
	 */
	public void s_foo() {
	}
}
