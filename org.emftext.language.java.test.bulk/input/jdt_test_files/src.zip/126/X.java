/**
 * @see A#A()
 */
public class X extends A {
	public X() { super(); }
}
