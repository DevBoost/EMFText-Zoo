public class X {
	public static X MyX;
	public static String s;
	void foo(String s1) {
		X.MyX.s = s;	}
}
