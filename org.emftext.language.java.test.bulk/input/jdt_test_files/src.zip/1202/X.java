public class X {
	Boolean myBool = null;
	void foo() {
		if (this.myBool) {}
	}
	public static void main(String[] args) {
		try {
			new X().foo();
			System.out.println("FAILURE");
		} catch(NullPointerException e) {
			System.out.println("SUCCESS");
		}
	}
}