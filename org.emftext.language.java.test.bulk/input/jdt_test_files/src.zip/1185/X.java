public class X {
	void foo(Object... i) { System.out.print(1); }
	void foo(int... i) { System.out.print(2); }
	public static void main(String[] args) {
		new X().foo(1);
		new X().foo(new Integer(1));
		new X().foo(1, new Integer(1));
	}
}
