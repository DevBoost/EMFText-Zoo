class A {
        long foo = 0L;
}

public class X extends A {
        public static void main(String[] args) {
			new X().bar();
        }
		void bar() {
	             Long s = this.foo;
                System.out.println("SUCCESS");
        }
}
