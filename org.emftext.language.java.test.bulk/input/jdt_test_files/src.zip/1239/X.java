public class X<T> {
	public <A extends T> X(A... t) {}
	<T> void foo(T... t) {}
	<T> void zip(T t) {}
	void test() {
		new X<Integer>(10, 20);
		foo(10);
		foo(10, 20);
		zip(10);
	}
}
