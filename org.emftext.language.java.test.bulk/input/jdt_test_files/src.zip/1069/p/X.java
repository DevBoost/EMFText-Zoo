package p;
public class X {
	public enum E implements Runnable {
		SUCCESS {};
		public void run(){}
	}
}
