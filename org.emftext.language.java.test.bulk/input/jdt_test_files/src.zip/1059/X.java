public enum X {
	A, B, C;
	public static void main(String[] args) {}
}
