import java.util.ArrayList;
import java.util.List;

public class X {
	public static void main(String[] args) {
		int[] tab = new int[] {0, 1, 2, 3, 4};
	    int sum = 0;
	    for (Integer i : tab) {
	    	sum += i;
	    }
        System.out.print(sum);
    }
}