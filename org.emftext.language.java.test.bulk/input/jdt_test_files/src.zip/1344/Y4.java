public class Y4 { 
	public static void main(String[] argv){ 
		if (new Y4().bar() == 3) 
			System.out.println("SUCCESS"); 
		else 
			System.out.println("FAILED"); 
	} 
	int bar() { 
		final int i = "xxx".length(); 
		final String s = this.toString(); 
		class X { 
			class AX { 
				int bar() { 
					class BX { 
						int foo() { 
							return new AX().foo(); 
						} 
					} 
					return new BX().foo(); 
				} 
				int foo() { 
					return i; 
				} 
			} 
		} 
		return new X().new AX().bar(); 
	} 
} 
