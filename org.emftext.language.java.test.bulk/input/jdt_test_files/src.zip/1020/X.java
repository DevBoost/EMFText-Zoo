public class X<T> {
  enum Option { ALPHA, BRAVO  };
  void method1(Option item) {
    switch (item) {
    case ALPHA:      break;
    case BRAVO:      break;
    }
  }
}
