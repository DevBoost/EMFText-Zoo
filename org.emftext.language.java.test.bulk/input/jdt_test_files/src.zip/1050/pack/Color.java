package pack;
enum Color {RED, GREEN, YELLOW, WHITE}