package jd.gui.swing.jdgui.events.waitcursor;

/**
 * @author Based on <a
 *         href="http://www.javaspecialists.eu/archive/Issue075.html">The Java
 *         Specialists' Newsletter</a>
 */
public interface DelayTimerCallback {

    public void trigger();

}
