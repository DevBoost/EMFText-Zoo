package jd.gui.swing.jdgui.components.speedmeter;

import java.util.EventListener;

public interface SpeedMeterListener extends EventListener {

    public void onSpeedMeterEvent(SpeedMeterEvent e);

}
