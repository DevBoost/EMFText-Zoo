package jd.http.ext;


public class FullBrowserEnviroment extends BasicBrowserEnviroment {

    public FullBrowserEnviroment() {
        super(null, null);
        // TODO Auto-generated constructor stub
    }

    public boolean isImageLoadingEnabled() {
        // TODO Auto-generated method stub
        return true;
    }

}
