package jd.http.ext.events;

import org.appwork.utils.event.Event;

public class HtmlFrameControllerEvent extends Event {

    public HtmlFrameControllerEvent(Object caller, int eventID, Object parameter) {
        super(caller, eventID, parameter);
        // TODO Auto-generated constructor stub
    }

}
