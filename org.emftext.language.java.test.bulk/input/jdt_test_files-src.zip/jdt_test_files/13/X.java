public class X {
    X() {
		final int i;
		synchronized (this) {
		    i = 8;
		}
    }  
  public static void main(String[] args) {}
}