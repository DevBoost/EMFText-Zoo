package test;
public class X {
	/**
	 * Valid local classes references 
	 *
	 * @see Visibility Valid ref: local class 
	 * @see Visibility.VcPublic Valid ref: visible inner class of local class 
	 * @see Visibility.AvcPublic Valid ref: visible inherited inner class of local class 
	 * @see test.Visibility Valid ref: local class 
	 * @see test.Visibility.VcPublic Valid ref: visible inner class of local class 
	 * @see test.Visibility.AvcPublic Valid ref: visible inherited inner class of local class 
	 */
	public X() {
	}
}
