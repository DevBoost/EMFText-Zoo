package p;
class A {
	A(char c) {}
}
class B {
	B(Exception ex) {}
	void foo() {} 
	class C { 
	    /**
	     * Link {@link #B(Exception)} OK
	     * Link {@link #B.C(String)} OK
	     * Link {@link #foo()} OK
	     * Link {@link #bar()} OK
	     */
	    public C(String str) {}
		void bar() {}
	}
}