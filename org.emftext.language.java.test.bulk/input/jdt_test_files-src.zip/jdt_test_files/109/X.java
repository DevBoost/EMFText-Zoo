public class X {
	
	{
		new Z().foo(2);
	}
}
