import java.util.Vector;
public class X {
	/**
	 * Valid local methods references with array
	 * 
	 * @see #smr_foo(char[] array, int[][] matrix, String[][][] dim, Vector[][][][] extra) Valid local method reference
	 * @see #smr_foo(char[], int[][], String[][][], Vector[][][][]) Valid local method reference
	 * @see #smr_foo(char[],int[][],java.lang.String[][][],java.util.Vector[][][][]) Valid local method reference
	 */  
	public X() {
	}
	public void smr_foo(char[] array, int[][] matrix, String[][][] dim, Vector[][][][] extra) {
	}
}
