package pkg;

public class X {
	/**
	 * @see Object:/ invalid reference
	 */
	public void foo() { 
	 
	}
}
