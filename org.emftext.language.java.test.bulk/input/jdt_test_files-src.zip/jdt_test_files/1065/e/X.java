package e;
public class X {
	void foo() {}
	class Y {
		/**
		 * {@link #foo}
		 * @see #foo
		 */
		void hoo() {}
	}
}
