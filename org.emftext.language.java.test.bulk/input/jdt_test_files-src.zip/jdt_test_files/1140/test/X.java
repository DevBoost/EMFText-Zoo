package test;
	/**
	 * Valid local class field references
	 *
	 * @see #x Valid ref: accessible field
	 * @see Visibility#vf_public Valid ref: visible field
	 * @see Visibility.VcPublic#vf_public Valid ref: visible field in visible inner class
	 */
public class X {
	int x;
	public void s_foo() {
	}
}
