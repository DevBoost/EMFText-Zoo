public class X {
	/**
	 * Valid @param declaration: 3 arguments, 3 tags in wrong order
	 * @param c Valid param, not well placed
	 * @param b Valid param, not well placed 
	 * @param a Valid param, not well placed
	 */
	public void p_foo(long a, long b, long c) {
	}
}
