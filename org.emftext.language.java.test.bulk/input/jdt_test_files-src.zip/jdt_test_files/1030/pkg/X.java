package pkg;

public class X {
	/**
	 * @see http://ftp.eclipse.org/
	 */
	public void foo() { 
	 
	}
}
