/**
 * No reasonable hint for resolving the {@link #getMax(A)}.
 */
public class X {
    /**
     * Extends Number method.
     * @see #getMax(A ipZ)
     */
    public <T extends Y> T getMax(final A<T> ipY) {
        return ipY.t();
    }
    
    /**
     * Extends Exception method.
     * @see #getMax(A ipY)
     */
    public <T extends Z> T getMax(final A<T> ipZ) {
        return ipZ.t();
    }
}
class A<T> {
	T t() { return null; }
}
class Y {}
class Z {}