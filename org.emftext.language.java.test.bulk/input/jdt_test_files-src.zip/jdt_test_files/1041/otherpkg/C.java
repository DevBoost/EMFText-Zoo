package otherpkg;
public class C {
        public static class Inner { }
}
