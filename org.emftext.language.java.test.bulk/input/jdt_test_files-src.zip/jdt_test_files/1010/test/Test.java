package test;
public interface Test {
	public class Level0 {
		public Level0() {}
	}
	public interface Member {
		public class Level1 {
			public Level1() {}
		}
	}
}
