import java.util.*;
public class X<T> {
X(List<T> lt) {}
}
class Y<U> extends X<U> {
/** @see X#X(List) */
Y(List<U> lu) { super(null); }
}
