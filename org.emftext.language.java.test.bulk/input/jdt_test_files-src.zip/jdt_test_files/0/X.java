public class X {
	X() {}
	X(double i) {
		this(i > 0 ? null : new Object());
		try {
			foo(6, false);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	X(Object o) {}
	int foo(int i, boolean b) {
		try {
			if (b) {
				return i;
			}
			return i + 1;
		} catch(Exception e) {
			return 5;
		}
	}
	public static void main(String[] args) {
		new X().foo(2, false);
		System.out.println("SUCCESS");
	}
}