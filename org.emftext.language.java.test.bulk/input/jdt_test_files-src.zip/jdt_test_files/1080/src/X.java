/**
 * @author {@link String}
 * @since {@link String}
 * @version {@link String}
 * @deprecated {@link String}
*/
public class X {
	/**
	 * @return {@link String}
	 * @since {@link String}
	 * @throws  Exception {@link String}
	 * @exception Exception {@link String}
	 * @serial {@link String}
	 * @serialData {@link String}
	 * @serialField {@link String}
	 * @deprecated {@link String}
	 */
	public String foo(String aParam) throws Exception {
		return new String();
	}
}