public class X {
private int unused1;

/**
 * Same value as {@link #unused1}
 */
private int unused2;
}
