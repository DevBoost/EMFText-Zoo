public class X {
	void foo(long[] longs) throws Exception {
		Object other = longs.clone();
	}
}
