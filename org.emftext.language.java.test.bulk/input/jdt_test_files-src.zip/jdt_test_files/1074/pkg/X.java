package pkg;

public class X extends Object {
	/**
	 * {@inheritDoc}
	 */
	public String toString() { 
		return "foo";
	}
}
