public class X { 
	/**
	 * {@value #MY_VALUE}
	 */
	public final static int MY_VALUE = 0; 
	/**
	 * {@value #MY_VALUE}
	 */
	public void foo() {}
	/**
	 * {@value #MY_VALUE}
	 */
	class Sub {} 
}
