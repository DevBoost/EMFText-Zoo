package pkg;

public class X {
	/**
	 * @see ://
	 */
	public void foo() { 
	 
	}
}
