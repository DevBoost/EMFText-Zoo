import java.util.Map;

public class X {
	Map fValueMap;

	public static void main(String[] args) {
		System.out.println("SUCCESS");
	}
	public Object[][] getAllChoices() {
		Object[][] all = new String[this.fValueMap.size()][];
		return all;
	}
}