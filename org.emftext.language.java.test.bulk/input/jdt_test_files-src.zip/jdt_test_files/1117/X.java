public class X {
	public void foo() {}
	/**
	 * Invalid javadoc comment
	 */
}
