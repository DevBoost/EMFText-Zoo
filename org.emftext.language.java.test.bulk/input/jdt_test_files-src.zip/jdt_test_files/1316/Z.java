public class Z {
  /** 
   * 
   * **   ** ** ** @deprecated */
	public Z() { 
	}
}
