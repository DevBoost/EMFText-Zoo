public class X {
	
	/**
	 * Valid @param declaration: 3 arguments, 3 tags in right order
	 * @param a Valid param
	 * @param b Valid param 
	 * @param c Valid param
	 */
	public void p_foo(int a, int b, int c) {
	}
}
