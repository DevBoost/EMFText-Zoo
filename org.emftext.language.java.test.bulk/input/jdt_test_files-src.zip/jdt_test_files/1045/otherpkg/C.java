package otherpkg;
public class C {
        public interface Inner { }
}
