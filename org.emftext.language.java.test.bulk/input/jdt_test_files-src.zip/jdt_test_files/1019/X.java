public class X {
	/**
	 * @see p.A#bar
	 */
	void foo() {}
}
