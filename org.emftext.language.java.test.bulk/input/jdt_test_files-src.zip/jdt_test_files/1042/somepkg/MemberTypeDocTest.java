package somepkg;
import otherpkg.C.Inner;
/**
 * {@link Inner} -- error/warning 
 */
public class MemberTypeDocTest {
      void m() { }
}
