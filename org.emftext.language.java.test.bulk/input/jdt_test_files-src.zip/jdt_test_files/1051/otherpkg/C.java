package otherpkg;
public interface C {
        public interface Inner { }
}
