public class X {
  /**
   * @see
   * @see UnknownClass
   */
  protected void foo() {
  }
}
