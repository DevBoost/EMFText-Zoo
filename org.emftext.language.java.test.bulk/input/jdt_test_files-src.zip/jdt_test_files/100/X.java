public class X {
	static long lfield;
	
	public static void main(String[] args) {
		lfield = args.length;
		lfield = args(args).length;
		
	}
	static String[] args(String[] args) {
		return args;
	}
}
