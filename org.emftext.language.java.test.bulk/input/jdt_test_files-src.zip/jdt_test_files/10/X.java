public class X {
	Object o;

	public static void main(String[] args) {
		X x;
		for (int i = 0; i < 10; i++) {
			if (i < 90) {
				x = new X();
				if (i > 4) {
					x.o = new Object();
				} else {
					x.o = "0";
				}
				switch (i) {
					case 0:
						if (x.o instanceof String) {
							System.out.print("1");
						}
						break;
					default: {
						Object diff = x.o;
						if (diff != null) {
							System.out.print("2");
						}
					}
				}
			}
		}
	}
}