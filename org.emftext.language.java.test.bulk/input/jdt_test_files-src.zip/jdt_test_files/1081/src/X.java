public class X {

	final static int WAIT_YES = 0;
	final static int WAIT_NO = 1;
	
	/**
	 * Do something more.
	 * 
	 * @param waitFlag {@link #WAIT_YES} or {@link #WAIT_NO}
	 */
	String foo(int waitFlag) {
		return "X";
	}
}
