public class X {
	/**
	 * Valid string references 
	 *
	 * @see "Valid normal string"
	 * @see "Valid \"string containing\" \"double-quote\""
	 */
	public void s_foo() {
	}
}
