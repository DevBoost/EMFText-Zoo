package test;
/** */
class X {
  /** */
  protected int x;
  /** */
  protected X() {}
  /** */
  protected void foo() {}
}
