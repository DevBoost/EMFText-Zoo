package d;
public interface X {
	void foo();
}
interface Y extends X {}
abstract class W implements Y {}
abstract class Z extends W {
	/**
	 * {@link #foo}
	 * @see #foo
	 */
	void hoo() {}
}
