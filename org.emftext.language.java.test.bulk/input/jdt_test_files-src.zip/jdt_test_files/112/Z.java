public class Z {
  /** 
   * Valid tags with deprecation at beginning
   *
   * @deprecated
   * @param x Valid param tag
   * @return Valid return tag
   * @exception IllegalArgumentException Valid throws tag
   * @throws NullPointerException Valid throws tag
   * @see X Valid see tag
   */
	public String foo(int x) { 
		return "";
	}
}
