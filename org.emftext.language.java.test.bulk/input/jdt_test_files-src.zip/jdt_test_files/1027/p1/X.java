package p1;
public class X {
	/**
	 * @return a
	 */
	boolean get() {
		return false;
	}
}
