/**
* @since
* 	description
* @author
* 	description
* @version
* 	description
*/
public class X {
	/**
	 * @param  aParam
	 *         description
	 * @return
	 *         description
	 * @since
	 *         description
	 * @throws NullPointerException
	 *         description
	 * @exception NullPointerException
	 *            description
	 * @serial
	 *         description
	 * @serialData
	 *         description
	 * @serialField
	 *         description
	 * @deprecated
	 *         description
	 */
	public String foo(String aParam) {
		return new String();
	}
}
