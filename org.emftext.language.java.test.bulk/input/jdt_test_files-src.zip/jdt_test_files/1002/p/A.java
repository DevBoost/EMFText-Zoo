package p;
class A { }
class C {
    /**
     * Link {@link #C(String)} was also wrongly warned...
     */
    private String fGerman;
    public C(String german) {
        fGerman = german;
    }
}