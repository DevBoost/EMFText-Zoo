package p;
class A {
	A(char c) {}
	class B {
		B(Exception ex) {}
	}
	void foo() {}
    /**
     * Link {@link #A(char)} OK 
     * Link {@link #A(String)} OK
     * Link {@link #foo()} OK
     * Link {@link #bar()} OK
     */
    public A(String str) {}
	void bar() {}
}