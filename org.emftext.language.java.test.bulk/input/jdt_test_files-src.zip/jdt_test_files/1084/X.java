import java.util.*;
public class X<T> {
X(ArrayList<T> alt) {}
}
class Y<U> extends X<U> {
/** @see X#X(ArrayList) */
Y(List<U> lu) { super(null); }
}
