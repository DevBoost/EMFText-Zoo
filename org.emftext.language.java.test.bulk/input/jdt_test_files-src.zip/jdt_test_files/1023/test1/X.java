package test1;
public class X {
	class Inner {
		class Level2 {
			class Level3 {}
		}
	}
}
