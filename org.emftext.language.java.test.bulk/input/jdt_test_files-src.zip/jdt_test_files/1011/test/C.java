package test;
public class C {
	/**
	 * @see Test.Level0#Test.Level0()
	 */
	Test.Level0 valid = new Test.Level0();
	/**
	 * @see Test.Level0#Level0()
	 */
	Test.Level0 invalid = new Test.Level0();
}
