public class X {
	/**
	/**
	/**
	/** 
	 * @param str
	 * @param x
	 */
	public void bar(String str, int x) {
	}
	public void foo() {
		bar("toto", 0 /* block comment inline */);
	}
}
