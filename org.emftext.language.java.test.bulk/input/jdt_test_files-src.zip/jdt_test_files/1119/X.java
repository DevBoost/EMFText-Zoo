	/**
	 * Valid string references 
	 *
	 * @see "Valid normal string"
	 * @see "Valid \"string containing\" \"double-quote\""
	 */
public class X {
	public void s_foo() {
	}
}
