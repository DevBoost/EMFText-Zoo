package pkg;

public class X {
	/**
	 * @see http:/ invalid reference
	 */
	public void foo() { 
	 
	}
}
