public class X {
X(int i) {}
}
class Y extends X {
/** @see X#X(int) */
Y(double d) { super(0); }
}
