package implicit;
public interface Valid {
	public class Level0 {
		/**
		 * @see #Valid.Level0() Valid
		 */
		public Level0() {}
		/**
		 * @see #Valid.Level0(String) Valid
		 */
		public Level0(String str) {}
	}
	public interface Member {
		public class Level1 {
			/**
			 * @see #Valid.Member.Level1() Valid
			 */
			public Level1() {}
			/**
			 * @see #Valid.Member.Level1(int) Valid
			 */
			public Level1(int x) {}
		}
	}
}
