public class X {
	public static void main(String[] args) {
		try {
			Object[][] all = new String[1][];
			all[0] = new Object[0];
		} catch (ArrayStoreException e) {
			System.out.println("SUCCESS");
		}
	}
}