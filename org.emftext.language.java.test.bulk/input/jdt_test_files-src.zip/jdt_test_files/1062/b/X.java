package b;
public class X {
	void foo() {}
}
class Y extends X {}
class W extends Y {}
class Z extends W {
	/**
	 * {@link #foo}
	 * @see #foo
	 */
	void hoo() {}
}
