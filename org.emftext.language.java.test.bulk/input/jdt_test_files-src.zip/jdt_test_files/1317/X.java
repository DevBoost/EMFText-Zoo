public class X {
	
	{
		new Z(2);
	}
}
