package pkg;

public class X extends Object {
	/**
	 * {@docRoot}
	 */
	public String toString() { 
		return "foo";
	}
}
