package i;
interface X {
	void foo();
}
interface Y {
	void foo(int i);
}
abstract class Z implements X, Y {
	/**
	 * @see #foo
	 */
	void bar() {
	}
}