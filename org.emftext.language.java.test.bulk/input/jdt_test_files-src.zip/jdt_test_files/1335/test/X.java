package test;
public class X {
	/**
	 * Valid external classes references 
	 *
	 * @see test.copy.VisibilityPublic Valid ref: visible class through import => no warning on import
	 */
	public X() {
	}
}
