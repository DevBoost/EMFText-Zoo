package test;
/** */
class X {
  /** */
  int x;
  /** */
	 X() {}
  /** */
  void foo() {}
}
