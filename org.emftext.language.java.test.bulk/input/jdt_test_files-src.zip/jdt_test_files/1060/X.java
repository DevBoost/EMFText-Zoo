public class X {
	void foo() {}
	/**
	 * {@link #foo}.
	 * @see #foo
	 */
	void goo() {}
}
