public class Z {
  /** 
   * Valid tags with deprecation at end
   *
   * @param x Valid param tag
   * @return Valid return tag
   * @throws NullPointerException Valid throws tag
   * @exception IllegalArgumentException Valid throws tag
   * @see X Valid see tag
   * @deprecated
   */
	public String foo(int x) { 
		return "";
	}
}
