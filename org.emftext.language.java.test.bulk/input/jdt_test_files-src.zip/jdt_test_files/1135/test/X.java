package test;
	/**
	 * Valid external classes references 
	 *
	 * @see test.copy.VisibilityPublic Valid ref: visible class through import => no warning on import
	 */
public class X {
	public void s_foo() {
	}
}
