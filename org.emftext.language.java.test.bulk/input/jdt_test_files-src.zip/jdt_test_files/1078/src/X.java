public class X {

	/**
	 * Do something more.
	 * 
	 * @param monitor The monitor
	 * @return {@link String X}
	 */
	String foo(Object monitor) {
		return "X";
	}
}
