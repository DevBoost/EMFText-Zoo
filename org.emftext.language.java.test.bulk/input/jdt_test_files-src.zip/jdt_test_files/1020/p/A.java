package p;
/** @deprecated */
public class A {
	void bar() {}
}
