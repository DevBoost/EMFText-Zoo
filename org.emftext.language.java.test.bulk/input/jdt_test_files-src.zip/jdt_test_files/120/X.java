public class X {
	/**
	 * Valid return declaration
	 *
	 * @return Return an int
	 */
	public int s_foo() {
	  return 0;
	}
}
