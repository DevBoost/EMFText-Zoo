package otherpkg;
public interface C {
        public static class Inner { }
}
