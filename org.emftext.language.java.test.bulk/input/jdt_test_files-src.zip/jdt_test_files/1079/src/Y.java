public class Y extends X {

	/**
	 * Do something more.
	 * 
	 * {@inheritDoc}
	 * 
	 * @param monitor {@inheritDoc}
	 * @return {@link String Y}
	 */
	String foo(Object monitor) {
		return "Y";
	}
}
