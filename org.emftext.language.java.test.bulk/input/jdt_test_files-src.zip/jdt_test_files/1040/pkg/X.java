package pkg;
public interface X
{
  /**
   * Test for bug {@link "https://bugs.eclipse.org/bugs/show_bug.cgi?id=170637"}
   * 
   * 
   * @param bar1 {@link X}
   * @param bar2 {@link X}
   * @param bar3 {@link X}
   * @param bar4 {@link X}
   * @param bar5 {@link X}
   * @param bar6 {@link X}
   * @param bar7 {@link X}
   * @param bar8 {@link X}
   * @param bar9 {@link X}
   * @param bar10 {@link X}
   * @param bar11 {@link X}
   * @param bar12 {@link X}
   * @param bar13 {@link X}
   * @param bar14 {@link X}
   * @param bar15 {@link X}
   * @param bar16 {@link X}
   * @param bar17 {@link X}
   * @param bar18 {@link X}
   * @param bar19 {@link X}
   * @param bar20 {@link X}
   * @param bar21 {@link X}
   * @param bar22 {@link X}
   * @param bar23 {@link X}
   * @param bar24 {@link X}
   * @param bar25 {@link X}
   * @param bar26 {@link X}
   * @param bar27 {@link X}
   * @param bar28 {@link X}
   * @param bar29 {@link X}
   * @param bar30 {@link X}
   * 
   * @return A string
   */
  public String foo(String bar1,
      String bar2,
      String bar3,
      String bar4,
      String bar5,
      String bar6,
      String bar7,
      String bar8,
      String bar9,
      String bar10,
      String bar11,
      String bar12,
      String bar13,
      String bar14,
      String bar15,
      String bar16,
      String bar17,
      String bar18,
      String bar19,
      String bar20,
      String bar21,
      String bar22,
      String bar23,
      String bar24,
      String bar25,
      String bar26,
      String bar27,
      String bar28,
      String bar29,
      String bar30
      );
}
