public class X {
	/**
	 * Invalid javadoc comment
	 */
}
