package pkg;

public class X {
	/**
	 * @see <a href="ccwww.xyzzy.com/rfc123.html">invalid></aa>
	 */
	public void foo() { 
	 
	}
}
