	/**
	 * Valid URL link references 
	 *
	 * @see <a href="http://java.sun.com/j2se/1.4.2/docs/tooldocs/windows/javadoc.html">Valid URL link reference</a>
	 */
public class X {
	public void s_foo() {
	}
}
