public class Z {
  /** 
   * Valid tags with deprecation in the middle
   *
   * @param x Valid param tag
   * @return Valid return tag
   * @deprecated
   * @exception IllegalArgumentException Valid throws tag
   * @throws NullPointerException Valid throws tag
   * @see X Valid see tag
   */
	public String foo(int x) { 
		return "";
	}
}
