public class Z {
  /** 
   * 
   * **   ** ** ** @deprecated */
	public void foo() { 
	}
}
