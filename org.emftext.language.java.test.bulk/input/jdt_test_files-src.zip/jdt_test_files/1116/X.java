	/**
	 * Valid class javadoc
	 * @author ffr
	 */
public class X {
	public void foo() {}
	/**
	 * Invalid javadoc comment
	 */
}
