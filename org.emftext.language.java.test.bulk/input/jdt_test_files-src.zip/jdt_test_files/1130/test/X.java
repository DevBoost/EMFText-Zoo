package test;
import test.copy.*;
	/**
	 * Valid external classes references 
	 *
	 * @see VisibilityPublic Valid ref: visible class through import => no warning on import
	 */
public class X {
	public void s_foo() {
	}
}
