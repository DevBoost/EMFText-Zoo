package boden;
import boden.IAFAState.ValidationException;
/**
 * @see ValidationException
 * @see IAFAState.ValidationException
 */
public class TestValid {
	/**  
	 * @see ValidationException#IAFAState.ValidationException(String, IAFAState)
	 */
	IAFAState.ValidationException valid1;
	/**
	 * @see IAFAState.ValidationException#IAFAState.ValidationException(String, IAFAState)
	 */
	IAFAState.ValidationException valid2;
}
