public class X {
	void foo(long[] longs) throws Exception {
		long[] other = longs.clone();
	}
}
