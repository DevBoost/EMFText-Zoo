public class X {
	public String getTexts(int i) [] {
		String[] texts = new String[1];
		return texts; 
	}
    public static void main(String[] args) {
		System.out.println("SUCCESS");
    }
}
