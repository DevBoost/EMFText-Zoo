package otherpkg;
public interface C {
        public class Inner { }
}
