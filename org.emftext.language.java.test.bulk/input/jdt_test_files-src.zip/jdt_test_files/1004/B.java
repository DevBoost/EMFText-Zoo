/**
 * Test bug 86769
 */
public class B {
	private class Level1 {
		private class InnerPrivate {
			private void pri_pri() {}
			void pri_def() {}
			protected void pri_pro() {}
			public void pri_pub() {}
		}
		class InnerDefault{
			private void def_pri() {}
			void def_def() {}
			protected void def_pro() {}
			public void def_pub() {}
		}
		protected class InnerProtected {
			private void pro_pri() {}
			void pro_def() {}
			protected void pro_pro() {}
			public void pro_pub() {} 
		}
		public class InnerPublic {
			private void pub_pri() {}
			void pub_def() {}
			protected void pub_pro() {}
			public void pub_pub() {}
		}
	}
}
