class Y extends X {
	/**
	 * {@link #foo}
	 * @see #foo
	 */
	void hoo() {}
}