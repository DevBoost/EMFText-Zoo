package pkg;

public class X {
	public X(String str, int anInt) {
	}
}
