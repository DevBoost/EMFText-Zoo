public class X {
	
	{
		new Z();
	}
}
