public class X {
	/**
	 * @\u0070\u0061\u0072\u0061\u006d str xxx
	 */
	void foo(String str) {}
}
