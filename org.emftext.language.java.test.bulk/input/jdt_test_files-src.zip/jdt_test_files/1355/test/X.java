package test;
public class X {
	/**
	 * Valid other package visible class methods references 
	 * 
	 * @see test.copy.VisibilityPublic#vm_public() Valid ref to not visible method of other package class
	 * @see test.copy.VisibilityPublic.VpPublic#vm_public() Valid ref to visible method of other package public inner class
	 */
	public X() {
	}
}
