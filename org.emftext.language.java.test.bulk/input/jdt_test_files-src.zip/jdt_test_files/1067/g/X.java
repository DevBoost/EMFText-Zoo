package g;
public class X {
	void foo(String str) {}
	void foo(int x) {}
}
class Y extends X {
	/**
	 * {@link #foo}
	 * @see #foo
	 */
	void hoo() {}
}
