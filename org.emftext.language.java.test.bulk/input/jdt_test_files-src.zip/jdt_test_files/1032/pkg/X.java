package pkg;

public class X {
	/**
	 * @see http://www.eclipse.org
	 */
	public void foo() { 
	 
	}
}
