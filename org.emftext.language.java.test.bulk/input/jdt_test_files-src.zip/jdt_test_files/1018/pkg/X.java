package pkg;

public class X {
	/**
	 * @see <a href="http://www.eclipse.org"><valid>value</valid></a>
	 */
	public void foo() { 
	 
	}
}
