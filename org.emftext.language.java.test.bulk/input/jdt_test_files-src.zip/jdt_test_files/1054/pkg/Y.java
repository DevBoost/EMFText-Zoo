package pkg;

public class Y extends X {
	private static int myInt = 0;
	/**
	 * @see X#X(String, int)
	 */
	public Y(String str) {
		super(str, myInt);
	}
}
