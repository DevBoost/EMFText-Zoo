/**
 * @see <a href="http://www.eclipse.org/">http://www.eclipse.org</a>
 * @see <a href="http://www.eclipse.org/">//</a>
 */
public class Link {}
