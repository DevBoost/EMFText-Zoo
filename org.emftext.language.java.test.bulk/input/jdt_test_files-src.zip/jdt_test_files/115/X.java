public class X {
	/**
	 * Valid @param: no tags, no args
	 * Valid @throws/@exception: no tags, no thrown exception
	 */
	public void p_foo() {
	}
}
