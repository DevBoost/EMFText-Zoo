public class X { 
	/**
	 * {@value}
	 */
	public final static int MY_VALUE = 0; 
	/**
	 * {@value}
	 */
	public void foo() {}
	/**
	 * {@value}
	 */
	class Sub {} 
}
