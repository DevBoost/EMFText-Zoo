package test;
/**
 * Valid class javadoc
 * @author ffr
 * @see "Test class X"
 */
public class X {
/**
 * Valid field javadoc
 * @see <a href="http://www.ibm.com">Valid URL</a>
 */
	public int x;

/**
 * Valid constructor javadoc
 * @param str Valid param tag
 * @throws NullPointerException Valid throws tag
 * @exception IllegalArgumentException Valid throws tag
 * @see X Valid see tag
 * @deprecated
 */
	public X(String str) {
	}
/**
 * Valid method javadoc
 * @param list Valid param tag
 * @throws NullPointerException Valid throws tag
 * @exception IllegalArgumentException Valid throws tag
 * @return Valid return tag
 * @see X Valid see tag
 * @deprecated
 */
	public String foo(java.util.Vector list) {
		return "";
	}
}
