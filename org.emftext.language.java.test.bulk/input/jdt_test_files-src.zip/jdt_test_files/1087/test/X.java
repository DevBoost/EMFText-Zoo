package test;
/** */
public class X {
  /** */
  public int x;
  /** */
	 public X() {}
  /** */
	 public void foo() {}
}
