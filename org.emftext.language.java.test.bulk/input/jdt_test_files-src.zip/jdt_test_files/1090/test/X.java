package test;
/** */
class X {
  /** */
  private int x;
  /** */
  private X() {}
  /** */
  private void foo() {}
}
