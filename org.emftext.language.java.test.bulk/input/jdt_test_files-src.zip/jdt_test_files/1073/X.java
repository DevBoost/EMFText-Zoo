/**
 * {@code}
 * {@literal}
 * @author
 * @deprecated
 * @since
 * @version
 * @generated
 * @code
 * @literal
*/
public class X {
	/**
	 * @param  aParam
	 * @return
	 * @throws NullPointerException
	 * @exception NullPointerException
	 */
	public String foo(String aParam) {
		return new String();
	}
	/**
	 * @serial
	 * @serialData
	 * @serialField
	 */
	Object field;
}
