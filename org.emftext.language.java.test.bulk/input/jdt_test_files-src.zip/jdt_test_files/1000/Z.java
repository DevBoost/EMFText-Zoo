public class Z {
	/** 
	 * @see X#x
	 * @deprecated
	 */
	public int x;
	/**
	 * @see X#foo()
	 * @deprecated
	 */
	public void foo() {}
}
