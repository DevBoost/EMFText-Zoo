import java.util.*;
public class X<T> {
X(Object o) {}
}
class Y<U> extends X<U> {
/** @see X#X(Object) */
Y(List<U> lu) { super(lu); }
}
