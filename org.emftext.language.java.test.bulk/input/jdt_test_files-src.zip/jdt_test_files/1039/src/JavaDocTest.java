public interface JavaDocTest
{
  /**
   * This is some stupid test...
   * 
   * {@link JavaDocTest}
   * 
   * @param bar1 {@link JavaDocTest}
   * @param bar2 {@link JavaDocTest}
   * @param bar3 {@link JavaDocTest}
   * @param bar4 {@link JavaDocTest}
   * @param bar5 {@link JavaDocTest}
   * @param bar6 {@link JavaDocTest}
   * @param bar7 {@link JavaDocTest}
   * @param bar8 {@link JavaDocTest}
   * @param bar9 {@link JavaDocTest}
   * @param bar10 {@link JavaDocTest}
   * @param bar11 {@link JavaDocTest}
   * @param bar12 {@link JavaDocTest}
   * @param bar13 {@link JavaDocTest}
   * 
   * @return A string!
   */
  public String foo(String bar1,
      String bar2,
      String bar3,
      String bar4,
      String bar5,
      String bar6,
      String bar7,
      String bar8,
      String bar9,
      String bar10,
      String bar11,
      String bar12,
      String bar13
      );

  /**
   * This is some more stupid test...
   * 
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * {@link JavaDocTest}
   * 
   * @param bar1 
   * @param bar2 
   * @param bar3 
   * @param bar4 
   * @param bar5 
   * @param bar6 
   * @param bar7 
   * @param bar8 
   * @param bar9 
   * @param bar10 
   * @param bar11 
   * @param bar12 
   * @param bar13 
   * 
   * @return A string!
   */
  public String foo2(String bar1,
      String bar2,
      String bar3,
      String bar4,
      String bar5,
      String bar6,
      String bar7,
      String bar8,
      String bar9,
      String bar10,
      String bar11,
      String bar12,
      String bar13
      );
}
