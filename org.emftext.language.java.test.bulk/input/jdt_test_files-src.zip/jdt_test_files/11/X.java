public class X {
	public static void main(String[] args) {
		X x;
		Object o;
		for (int i = 0; i < 10; i++) {
			if (i < 90) {
				x = new X();
				if (i > 4) {
					o = new Object();
				} else {
					o = null;
				}
				switch (i) {
					case 0:
						if (o instanceof String) {
							System.out.print("1");
							return;
						} else {
							break;
						}
					default: {
						Object diff = o;
						if (diff != null) {
							System.out.print("2");
						}
						break;
					}
				}
				System.out.print("3");
			}
		}
	}
}