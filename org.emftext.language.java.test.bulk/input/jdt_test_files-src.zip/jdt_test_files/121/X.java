public class X {
	/**
	 * Valid empty return declaration
	 *
	 * @return string
	 */
	public String s_foo() {
	  return "";
	}
}
