public class X {

  void foo() {
      synchronized (this) {
        int n=0;
        try {
           Thread.sleep(n); 
        } catch (Exception e ) {
        }
     }
  }
  
  public static void main(String[] args) {}
}