public class X {
/**
* @see #X(int)
*/
X(int i) {
}
}
