public class X {
	public void p_foo() {
	}
}
