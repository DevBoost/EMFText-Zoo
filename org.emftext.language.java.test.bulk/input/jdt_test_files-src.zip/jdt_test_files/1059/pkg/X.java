package pkg;

public class X {
private class unused1 {}
/**
 * {@link X.unused1}
 */
private class unused2 {}
}
