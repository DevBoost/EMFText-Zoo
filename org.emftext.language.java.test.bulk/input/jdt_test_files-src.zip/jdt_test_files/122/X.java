public class X {
	/**
	 * Valid return declaration
	 *
	 * @return Vector A list of things
	 */
	public java.util.Vector s_foo() {
	  return new java.util.Vector();
	}
}
