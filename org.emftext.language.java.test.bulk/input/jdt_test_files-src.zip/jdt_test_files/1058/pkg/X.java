package pkg;

public class X {
private void unused1() {}
/**
 * Same value as {@link #unused1()}
 */
private void unused2() {}
}
