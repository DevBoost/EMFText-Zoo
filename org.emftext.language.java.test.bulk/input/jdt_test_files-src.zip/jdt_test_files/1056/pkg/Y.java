package pkg;

public class Y extends X {
	/**
	 * @param str
	 * @param anInt
	 * @see X#X(String, int)
	 */
	public Y(String str, int anInt, int anotherInt) {
		super(str, anInt);
	}
}
