package boden;
public interface IAFAState {
    public class ValidationException extends Exception {
        public ValidationException(String variableName, IAFAState subformula) {
            super("Variable '"+variableName+"' may be unbound in '"+subformula+"'");
        }
        public void method() {}
    }
    /**
     * Validates a formula for consistent bindings. Bindings are consistent, when at each point in time,
     * the set of povided variables can be guaranteed to be a superset of the set of required variables.
     * @throws ValidationException Thrown if a variable is unbound. 
     * @see ValidationException#IAFAState.ValidationException(String, IAFAState)
     * @see IAFAState.ValidationException#method()
     * @see ValidationException
     * {@link ValidationException}
     */
    public void validate() throws ValidationException;
}
