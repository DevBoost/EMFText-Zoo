package otherpkg;
public class C {
        public class Inner { }
}
