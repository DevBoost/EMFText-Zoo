package h;
public class X {
	void foo(String str) {}
}
class Y extends X {
	/**
	 * {@link #foo}
	 * @see #foo
	 */
	void hoo() {}
}
