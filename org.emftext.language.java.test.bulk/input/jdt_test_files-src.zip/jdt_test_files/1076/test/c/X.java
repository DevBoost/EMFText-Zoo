package test.c;

public class X {
	static class Y { 
	}
	void foo(Y y) {}
	/**
	 * @see #foo(X.Y)
	 */
	void bar() {}
}
