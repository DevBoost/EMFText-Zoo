package c;
public interface X {
	void foo();
}
interface Y extends X {
	/**
	 * {@link #foo}
	 * @see #foo
	 */
	void hoo();
}
