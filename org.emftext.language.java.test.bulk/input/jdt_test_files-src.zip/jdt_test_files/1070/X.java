public class X {
	public static class Param {
       /**
         * warning expected when compliance < 1.5 {@link X#setParams(Param[])}
         * no warning expected {@link X#setParams(X.Param[])}
         */
        public int getIndex() {
                    return 0;
        }
    }
    public void setParams(Param[] params) {
	}
}
