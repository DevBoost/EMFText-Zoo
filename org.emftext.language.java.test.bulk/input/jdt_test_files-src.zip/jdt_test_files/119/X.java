public class X {
	/**
	 * Valid @throws tags: documented exception are unchecked
	 * @throws IllegalArgumentException Valid unchecked exception (java.lang.Runtime subclass)
	 * @exception NullPointerException Valid unchecked exception (java.lang.Runtime subclass)
	 * @throws java.awt.AWTError Valid unchecked exception (java.lang.Error subclass)
	 * @exception OutOfMemoryError Valid unchecked exception (java.lang.Runtime subclass)
	 */
	public void t_foo() {
	}
}
