package com.google.gwt.core.ext.typeinfo.test;

public abstract class CA implements IA {
  
  public final void caNotOverridableFinal() {
  }
  
  private final void caNotOverridablePrivate() {
  }
  
}
