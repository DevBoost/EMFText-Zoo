package com.google.gwt.core.ext.typeinfo.test;

public interface IC extends IB, IA {

  void ib();

  void ib(int x, Object y);

  void ic();

  void ic(int x, Object y);

}
