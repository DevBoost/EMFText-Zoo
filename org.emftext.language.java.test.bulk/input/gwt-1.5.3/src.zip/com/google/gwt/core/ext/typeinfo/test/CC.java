package com.google.gwt.core.ext.typeinfo.test;

public abstract class CC extends CB implements IC {

}
