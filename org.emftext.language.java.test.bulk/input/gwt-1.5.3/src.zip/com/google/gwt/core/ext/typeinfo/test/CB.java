package com.google.gwt.core.ext.typeinfo.test;

public abstract class CB extends CA implements IB {
  
  public abstract void ic();
  
}
