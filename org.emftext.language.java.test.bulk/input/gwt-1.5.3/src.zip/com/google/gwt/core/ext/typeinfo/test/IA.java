package com.google.gwt.core.ext.typeinfo.test;

public interface IA {

  void foo(); 
  
  void ia();

  void ia(int x, Object y);
}
