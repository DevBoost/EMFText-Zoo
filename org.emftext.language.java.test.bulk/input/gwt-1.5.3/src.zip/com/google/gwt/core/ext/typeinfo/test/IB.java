package com.google.gwt.core.ext.typeinfo.test;

public interface IB extends IA {

  void foo();

  void ib();

  void ib(int x, Object y);
}
