package com.google.gwt.examples.i18n;

import com.google.gwt.i18n.client.Constants;

public interface MyConstants extends Constants {
  String helloWorld();
  String goodbyeWorld();
}
