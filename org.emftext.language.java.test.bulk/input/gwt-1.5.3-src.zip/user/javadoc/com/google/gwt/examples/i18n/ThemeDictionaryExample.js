var CurrentTheme = {
  highlightColor: "#FFFFFF",
  shadowColor: "#808080",
  errorColor: "#FF0000",
  errorIconSrc: "stopsign.gif"
};
